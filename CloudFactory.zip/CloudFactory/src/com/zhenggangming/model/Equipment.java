package com.zhenggangming.model;

import java.util.HashMap;

public class Equipment {
    private String id;
    private String serialNumber;
    private String name;
    private String kind;
    private String standard;
    private String equipmentState = "关机";
    private String rentState = "未被租用";
    private String ownerShip = "";
    private String description;
    private HashMap<Product,Integer> capacity = new HashMap<Product,Integer>(); 
	public Equipment(String id, String serialNumber, String name, String kind, String standard, String equipmentState,
			String rentState, String ownerShip, String description, HashMap<Product, Integer> map) {
		super();
		this.id = id;
		this.serialNumber = serialNumber;
		this.name = name;
		this.kind = kind;
		this.standard = standard;
		this.equipmentState = equipmentState;
		this.rentState = rentState;
		this.ownerShip = ownerShip;
		this.description = description;
		this.capacity = map;
	}
	public Equipment() {}
	
	public HashMap<Product, Integer> getCapacity() {
		return capacity;
	}
	public void setCapacity(HashMap<Product, Integer> map) {
		this.capacity = map;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	public String getStandard() {
		return standard;
	}
	public void setStandard(String standard) {
		this.standard = standard;
	}
	public String getEquipmentState() {
		return equipmentState;
	}
	public void setEquipmentState(String equipmentState) {
		this.equipmentState = equipmentState;
	}
	public String getRentState() {
		return rentState;
	}
	public void setRentState(String rentState) {
		this.rentState = rentState;
	}
	public String getOwnerShip() {
		return ownerShip;
	}
	public void setOwnerShip(String ownerShip) {
		this.ownerShip = ownerShip;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
}
