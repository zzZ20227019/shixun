package com.zhenggangming.model;

import java.util.ArrayList;

public class User {
	private String id;//编号 唯一标识
    private String account;//用户账户
    private String password;//登录密码
    private String userName;//用户真实姓名
    private String phone;//电话
    private String registerKind;//注册类别
    private String factoryName;//工厂名称
    private String introduction;//工厂介绍
    private String power;//用户权限
    private String state;//账户状态
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPower() {
		return power;
	}
	public void setPower(String power) {
		this.power = power;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String contact) {
		this.phone = contact;
	}
	public String getRegisterKind() {
		return registerKind;
	}
	public void setRegisterKind(String registerKind) {
		this.registerKind = registerKind;
	}
	public String getFactoryName() {
		return factoryName;
	}
	public void setFactoryName(String factoryName) {
		this.factoryName = factoryName;
	}
	public String getIntroduction() {
		return introduction;
	}
	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}
	
	public User(String id, String account, String password, String userName, String phone, String registerKind,
			String factoryName, String introduction, String power, String state) {
		super();
		this.id = id;
		this.account = account;
		this.password = password;
		this.userName = userName;
		this.phone = phone;
		this.registerKind = registerKind;
		this.factoryName = factoryName;
		this.introduction = introduction;
		this.power = power;
		this.state = state;
	}
	public User() {}
	
    
}
