package com.zhenggangming.model;

public class Product {
    private String id;
    private String serialNumber;
    private String kind;
    private String name;
    private String standard;
    private String description;
	public Product(String id, String serialNumber, String kind, String name, String standard, String description) {
		super();
		this.id = id;
		this.serialNumber = serialNumber;
		this.kind = kind;
		this.name = name;
		this.standard = standard;
		this.description = description;
	}
	public Product() {}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStandard() {
		return standard;
	}
	public void setStandard(String standard) {
		this.standard = standard;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
}
