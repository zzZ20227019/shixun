package com.zhenggangming.model;

public class Order {
    private String id;
    private String serialNumber;
    private String name;
    private int number;
    private String JiaoFuDate;
    private String TouBiaoEndDate;
    private String receiver;
    private int phone;
    private String address;
    private String orderState = "保存";
    private User ZhongBiaoFactory = null;
	public Order(String id, String name, int number, String jiaoFuDate, String touBiaoEndDate, String receiver,
			int phone, String address, String orderState,String serialNumber,User zbf) {
		super();
		this.id = id;
		this.name = name;
		this.number = number;
		JiaoFuDate = jiaoFuDate;
		TouBiaoEndDate = touBiaoEndDate;
		this.receiver = receiver;
		this.phone = phone;
		this.address = address;
		this.orderState = orderState;
		this.serialNumber = serialNumber;
		this.ZhongBiaoFactory = zbf;
	}
    public Order() {}
    
	public User getZhongBiaoFactory() {
		return ZhongBiaoFactory;
	}
	public void setZhongBiaoFactory(User zhongBiaoFactory) {
		ZhongBiaoFactory = zhongBiaoFactory;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public String getJiaoFuDate() {
		return JiaoFuDate;
	}
	public void setJiaoFuDate(String jiaoFuDate) {
		JiaoFuDate = jiaoFuDate;
	}
	public String getTouBiaoEndDate() {
		return TouBiaoEndDate;
	}
	public void setTouBiaoEndDate(String touBiaoEndDate) {
		TouBiaoEndDate = touBiaoEndDate;
	}
	public String getReceiver() {
		return receiver;
	}
	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}
	public int getPhone() {
		return phone;
	}
	public void setPhone(int phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getOrderState() {
		return orderState;
	}
	public void setOrderState(String orderState) {
		this.orderState = orderState;
	}
    
}
