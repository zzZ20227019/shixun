package com.zhenggangming.Dao;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.zhenggangming.model.Order;
import com.zhenggangming.model.User;
import com.zhenggangming.utils.DataFileName;
import com.zhenggangming.utils.DataUtils;
import com.zhenggangming.utils.Json;

public class OrderDao {
	//保存订单类别
	public boolean saveOrder(Order order) throws IOException {
		//把用户信息写入文件
		//把对象转换为json字符串
		String json = Json.objectToJson(order);
		DataUtils.writeDate(DataFileName.ORDER.toString(), json);
		return true;	
	}
    //获取订单列表的方法
	public ArrayList<Order> findOrderList() throws Exception{
		String json = DataUtils.readData(DataFileName.ORDER.getName());
		//System.out.println(json);
		if(json.length()==0) {
			return null;
		}else {
			ArrayList<Order> orderList = new ArrayList<>();
			//把json字符串拆分为一个由多个json字符串组成的数组
			String[] orders = json.split("/");
			for(String str : orders) {
				Order pd = Json.jsonToObject(str, Order.class);
				orderList.add(pd);
			}
			return orderList;
		}
	}
	//获取id的方法，在最大id上加一，并返回
	public String getMaxId() throws Exception {
		//获得文件中所有用户信息
		ArrayList<Order> orderList = null;
		orderList = findOrderList();
		int max=0;
		if(orderList == null || orderList.size()==0)
		{
			return "1";
		}else {
			for(int i=0;i<orderList.size();i++)
			{
				if(Integer.parseInt(orderList.get(i).getId())>max) {
					max=Integer.parseInt(orderList.get(i).getId());
				}
			}
			String str = String.valueOf(max+1);
			return str;
		}
		
	}
	//获取产品编号----系统时间编号，精确到毫秒
	public String getOrderNumber() {
		Date now = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		String str = "Ord-"+sdf.format(now);
		return str;
	}
	//   经销商删除订单
	public void deleteOrder(ArrayList<String> list) throws Exception {
		ArrayList<Order> orderList = findOrderList();
		for(int i=0;i<list.size();i++) {
			for(int j=0;j<orderList.size();j++) {
				if(list.get(i).equals(orderList.get(j).getId())) {
					if(!orderList.get(j).getOrderState().equals("保存") ) {
						continue;
					}else {
						orderList.remove(orderList.get(j));	
					}
				}
			}
		}
		DataUtils.deleteDataFile(DataFileName.ORDER.toString());
		if(orderList.size()==0) {
			DataUtils.createFile(DataFileName.ORDER.toString());
		}
		for(int i=0;i<orderList.size();i++) {
			String json = Json.objectToJson(orderList.get(i));
			DataUtils.writeDate(DataFileName.ORDER.toString(), json);
		}
	}
//	//云工厂管理员删除设备（若删的是租用的设备，则还回去）
//	public void deleteOrder2(ArrayList<String> list,String factoryName) throws Exception {
//		ArrayList<Order> orderList = findOrderList();
//		for(int i=0;i<list.size();i++) {
//			for(int j=0;j<orderList.size();j++) {
//				if(list.get(i).equals(orderList.get(j).getId())) {
//					if(orderList.get(j).getRentState().equals("已被租用")) {
//						orderList.get(j).setRentState("未被租用");
//						orderList.get(j).setOwnerShip("");
//					}else {
//						orderList.remove(orderList.get(j));	
//					}
//				}
//			}
//		}
//		DataUtils.deleteDataFile(DataFileName.ORDER.toString());
//		if(orderList.size()==0) {
//			DataUtils.createFile(DataFileName.ORDER.toString());
//		}
//		for(int i=0;i<orderList.size();i++) {
//			String json = Json.objectToJson(orderList.get(i));
//			DataUtils.writeDate(DataFileName.ORDER.toString(), json);
//		}
//	}
//	//云管理员租用设备
//	public void rentOrder(ArrayList<String> list,String factoryName) throws Exception {
//		ArrayList<Order> orderList = findOrderList();
//		for(int i=0;i<list.size();i++) {
//			for(int j=0;j<orderList.size();j++) {
//				if(list.get(i).equals(orderList.get(j).getId())) {
//					if(orderList.get(j).getRentState().equals("未被租用")) {
//						orderList.get(j).setRentState("已被租用");
//						orderList.get(j).setOwnerShip(factoryName);
//					}
//				}
//			}
//		}
//		DataUtils.deleteDataFile(DataFileName.ORDER.toString());
//		if(orderList.size()==0) {
//			DataUtils.createFile(DataFileName.ORDER.toString());
//		}
//		for(int i=0;i<orderList.size();i++) {
//			String json = Json.objectToJson(orderList.get(i));
//			DataUtils.writeDate(DataFileName.ORDER.toString(), json);
//		}
//	}
	
	
	//改变设备信息   
	public void modifyOrder(Order pk) throws Exception {
		ArrayList<Order> orderList = findOrderList();
		for(int i=0;i<orderList.size();i++) {
			if(orderList.get(i).getId().equals(pk.getId())) {
				orderList.remove(i);
				orderList.add(i, pk);
			}
		}
		DataUtils.deleteDataFile(DataFileName.ORDER.toString());
		if(orderList.size()==0) {
			DataUtils.createFile(DataFileName.ORDER.toString());
		}
		for(int i=0;i<orderList.size();i++) {
			String json = Json.objectToJson(orderList.get(i));
			DataUtils.writeDate(DataFileName.ORDER.toString(), json);
		}
		
	}
	
	//根据orderNumber查询订单
		public Order searchByOrderNumber(String orderNumber) throws Exception {
			ArrayList<Order> list = new ArrayList<>();
			list = findOrderList();
			for(Order pk : list) {
				if(pk.getSerialNumber().equals(orderNumber)) {
					return pk;
				}
			}
			return null;
		}
		
	//根据id查询订单
			public Order searchById(String id) throws Exception {
				ArrayList<Order> list = new ArrayList<>();
				list = findOrderList();
				for(Order pk : list) {
					if(pk.getId().equals(id)) {
						return pk;
					}
				}
				return null;
			}
	//根据factotyId查询订单
        public ArrayList<Order> searchByFactoryId(String factoryId) throws Exception {
			ArrayList<Order> list = findOrderList();
			for(Order o : list) {
				if(o.getZhongBiaoFactory().getId().equals(factoryId)) {
					list.add(o);
				}
			}
			return list;
		}
		
	//切换订单状态
		public void modifyOrderState(ArrayList<String> list) throws Exception {
			ArrayList<Order> orderList = findOrderList();
			Order eq = null;
			for(int i=0;i<list.size();i++) {
				eq = searchByOrderNumber(list.get(i));
				for(int j=0;j<orderList.size();j++) {
					if(list.get(i).equals(orderList.get(j).getSerialNumber())) {
						if(eq.getOrderState().equals("保存")) {
							eq.setOrderState("发布");
						}else if(eq.getOrderState().equals("发布")) {
							eq.setOrderState("已被接单");
						}else if(eq.getOrderState().equals("已被接单")) {
							eq.setOrderState("正在生产");
						}else if(eq.getOrderState().equals("正在生产")) {
							eq.setOrderState("已发货");
						}else if(eq.getOrderState().equals("已发货")) {
							eq.setOrderState("已签收");
						}else if(eq.getOrderState().equals("已签收")) {
							eq.setOrderState("已完成");
						}
						orderList.remove(j);
						orderList.add(j, eq);
						System.out.println(orderList.get(j).getOrderState());
					}
				}
			}
			DataUtils.deleteDataFile(DataFileName.ORDER.toString());
			if(orderList.size()==0) {
				DataUtils.createFile(DataFileName.ORDER.toString());
			}
			for(int i=0;i<orderList.size();i++) {
				String json = Json.objectToJson(orderList.get(i));
				DataUtils.writeDate(DataFileName.ORDER.toString(), json);
			}
			
		}
		//设置订单的中标工厂
		public void setZhongBiaoFactory(User user,String orderNumber) throws Exception {
			ArrayList<Order> list = findOrderList();
			for(int i=0;i<list.size();i++) {
				if(list.get(i).getSerialNumber().equals(orderNumber)) {
					list.get(i).setZhongBiaoFactory(user);
				}
			}
			DataUtils.deleteDataFile(DataFileName.ORDER.toString());
			if(list.size()==0) {
				DataUtils.createFile(DataFileName.ORDER.toString());
			}
			for(int i=0;i<list.size();i++) {
				String json = Json.objectToJson(list.get(i));
				DataUtils.writeDate(DataFileName.ORDER.toString(), json);
			}
		}
//		//根据工厂名称获得工厂中所有的设备
//		public ArrayList<Order> getFactoryOrderList(String factoryName) throws Exception {
//			ArrayList<Order> list1 = findOrderList();
//			ArrayList<Order> list2 = new ArrayList<Order>();
//			for(Order ep : list1) {
//				if(ep.getOwnerShip().equals(factoryName)) {
//					list2.add(ep);
//				}
//			}
//			return list2;
//		}
//		//获取产能中心所有未被租用的设备
//		public ArrayList<Order> getUnrentList() throws Exception {
//			ArrayList<Order> list1 = findOrderList();
//			ArrayList<Order> list2 = new ArrayList<Order>();
//			for(Order ep : list1) {
//				if(ep.getRentState().equals("未被租用")) {
//					list2.add(ep);
//				}
//			}
//			return list2;
//		}
//		//通过更新数据，来达到增加产能
//		public void addCapacity(Order ep) throws Exception {
//			ArrayList<Order> list1 = findOrderList();
//			for(int i=0;i<list1.size();i++) {
//				if(list1.get(i).getId().equals(ep.getId())) {
//					 list1.remove(i);
//					 list1.add(i, ep);
//				}
//			}
//			DataUtils.deleteDataFile(DataFileName.ORDER.toString());
//			if(list1.size()==0) {
//				DataUtils.createFile(DataFileName.ORDER.toString());
//			}
//			for(int i=0;i<list1.size();i++) {
//				String json = Json.objectToJson(list1.get(i));
//				DataUtils.writeDate(DataFileName.ORDER.toString(), json);
//			}
//		}
		
		//通过订单状态来获取订单列表
		public ArrayList<Order> getListByOrderState(String orderState) throws Exception {
			ArrayList<Order> list = findOrderList();
			ArrayList<Order> list2 = new ArrayList<Order>();
			for(Order o : list) {
				if(o.getOrderState().equals(orderState)) {
					list2.add(o);
				}
			}
			
			return list2;
		}
		
		//获得工厂自己已经中标的订单
		public ArrayList<Order> getZhongBiaoList(String orderState, User user) throws Exception {
			ArrayList<Order> list = findOrderList();
			ArrayList<Order> list2 = new ArrayList<Order>();
			for(Order o : list) {
				if(!o.getOrderState().equals("保存") && !o.getOrderState().equals("发布") && o.getZhongBiaoFactory().getFactoryName().equals(user.getFactoryName())) {
					list2.add(o);
				}
			}
			
			return list2;
		}
		public void modifyOrderState1(ArrayList<String> list) throws Exception {
			ArrayList<Order> orderList = findOrderList();
			Order eq = null;
			for(int i=0;i<list.size();i++) {
				eq = searchByOrderNumber(list.get(i));
				for(int j=0;j<orderList.size();j++) {
					if(list.get(i).equals(orderList.get(j).getSerialNumber())) {
						eq.setOrderState("正在生产");
						orderList.remove(j);
						orderList.add(j, eq);
						System.out.println(orderList.get(j).getOrderState());
					}
				}
			}
			DataUtils.deleteDataFile(DataFileName.ORDER.toString());
			if(orderList.size()==0) {
				DataUtils.createFile(DataFileName.ORDER.toString());
			}
			for(int i=0;i<orderList.size();i++) {
				String json = Json.objectToJson(orderList.get(i));
				DataUtils.writeDate(DataFileName.ORDER.toString(), json);
			}
			
		}
		public void modifyOrderState2(ArrayList<String> list) throws Exception {
			ArrayList<Order> orderList = findOrderList();
			Order eq = null;
			for(int i=0;i<list.size();i++) {
				eq = searchByOrderNumber(list.get(i));
				for(int j=0;j<orderList.size();j++) {
					if(list.get(i).equals(orderList.get(j).getSerialNumber())) {
						eq.setOrderState("已发货");
						orderList.remove(j);
						orderList.add(j, eq);
						System.out.println(orderList.get(j).getOrderState());
					}
				}
			}
			DataUtils.deleteDataFile(DataFileName.ORDER.toString());
			if(orderList.size()==0) {
				DataUtils.createFile(DataFileName.ORDER.toString());
			}
			for(int i=0;i<orderList.size();i++) {
				String json = Json.objectToJson(orderList.get(i));
				DataUtils.writeDate(DataFileName.ORDER.toString(), json);
			}
		}
		//判断订单是否为已发货
		public boolean IsFaHuo(String orderNumber) throws Exception {
			ArrayList<Order> list = findOrderList();
			for(Order o : list) {
				if(o.getSerialNumber().equals(orderNumber)) {
					if(!o.getOrderState().equals("已发货")) {
						return false;
					}else {
						return true;
					}
				}
			}
			return false;
		}
		public void modifyOrderState3(ArrayList<String> list) throws Exception {
			ArrayList<Order> orderList = findOrderList();
			Order eq = null;
			for(int i=0;i<list.size();i++) {
				eq = searchByOrderNumber(list.get(i));
				for(int j=0;j<orderList.size();j++) {
					if(list.get(i).equals(orderList.get(j).getSerialNumber())) {
						eq.setOrderState("已签收");
						orderList.remove(j);
						orderList.add(j, eq);
						System.out.println(orderList.get(j).getOrderState());
					}
				}
			}
			DataUtils.deleteDataFile(DataFileName.ORDER.toString());
			if(orderList.size()==0) {
				DataUtils.createFile(DataFileName.ORDER.toString());
			}
			for(int i=0;i<orderList.size();i++) {
				String json = Json.objectToJson(orderList.get(i));
				DataUtils.writeDate(DataFileName.ORDER.toString(), json);
			}
			
		}
		public void modifyOrderState4(ArrayList<String> list) throws Exception {
			ArrayList<Order> orderList = findOrderList();
			Order eq = null;
			for(int i=0;i<list.size();i++) {
				eq = searchByOrderNumber(list.get(i));
				for(int j=0;j<orderList.size();j++) {
					if(list.get(i).equals(orderList.get(j).getSerialNumber())) {
						eq.setOrderState("已完成");
						orderList.remove(j);
						orderList.add(j, eq);
						System.out.println(orderList.get(j).getOrderState());
					}
				}
			}
			DataUtils.deleteDataFile(DataFileName.ORDER.toString());
			if(orderList.size()==0) {
				DataUtils.createFile(DataFileName.ORDER.toString());
			}
			for(int i=0;i<orderList.size();i++) {
				String json = Json.objectToJson(orderList.get(i));
				DataUtils.writeDate(DataFileName.ORDER.toString(), json);
			}
			
		}
}

