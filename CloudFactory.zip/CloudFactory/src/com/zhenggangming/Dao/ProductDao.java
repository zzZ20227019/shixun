package com.zhenggangming.Dao;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.zhenggangming.model.Product;
import com.zhenggangming.utils.DataFileName;
import com.zhenggangming.utils.DataUtils;
import com.zhenggangming.utils.Json;

public class ProductDao {
	//保存产品类别
		public boolean saveProduct(Product product) throws IOException {
			//把用户信息写入文件
			//把对象转换为json字符串
			String json = Json.objectToJson(product);
			DataUtils.writeDate(DataFileName.PRODUCT.toString(), json);
			return true;	
		}
	    //获取产品类别列表的方法
		public ArrayList<Product> findProductList() throws Exception{
			String json = DataUtils.readData(DataFileName.PRODUCT.getName());
			//System.out.println(json);
			if(json.length()==0) {
				return null;
			}else {
				ArrayList<Product> productList = new ArrayList<>();
				//把json字符串拆分为一个由多个json字符串组成的数组
				String[] products = json.split("/");
				for(String str : products) {
					Product pd = Json.jsonToObject(str, Product.class);
					productList.add(pd);
				}
				return productList;
			}
		}
		//获取id的方法，在最大id上加一，并返回
		public String getMaxId() throws Exception {
			//获得文件中所有用户信息
			ArrayList<Product> productList = null;
			productList = findProductList();
			int max=0;
			if(productList == null || productList.size()==0)
			{
				return "1";
			}else {
				for(int i=0;i<productList.size();i++)
				{
					if(Integer.parseInt(productList.get(i).getId())>max) {
						max=Integer.parseInt(productList.get(i).getId());
					}
				}
				String str = String.valueOf(max+1);
				return str;
			}
			
		}
		//获取产品编号----系统时间编号，精确到毫秒
		public String getProductNumber() {
			Date now = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			String str = "Pro-"+sdf.format(now);
			return str;
		}
		//删除产品类别
		public void deleteProduct(ArrayList<String> list) throws Exception {
			ArrayList<Product> productList = findProductList();
			for(int i=0;i<list.size();i++) {
				for(int j=0;j<productList.size();j++) {
					if(list.get(i).equals(productList.get(j).getId())) {
						productList.remove(productList.get(j));
					}
				}
			}
			DataUtils.deleteDataFile(DataFileName.PRODUCT.toString());
			if(productList.size()==0) {
				DataUtils.createFile(DataFileName.PRODUCT.toString());
			}
			for(int i=0;i<productList.size();i++) {
				String json = Json.objectToJson(productList.get(i));
				DataUtils.writeDate(DataFileName.PRODUCT.toString(), json);
			}
		}
		//改变产品类别
		public void modifyProduct(Product pk) throws Exception {
			ArrayList<Product> productList = findProductList();
			for(int i=0;i<productList.size();i++) {
				if(productList.get(i).getId().equals(pk.getId())) {
					productList.remove(i);
					productList.add(i, pk);
				}
			}
			DataUtils.deleteDataFile(DataFileName.PRODUCT.toString());
			if(productList.size()==0) {
				DataUtils.createFile(DataFileName.PRODUCT.toString());
			}
			for(int i=0;i<productList.size();i++) {
				String json = Json.objectToJson(productList.get(i));
				DataUtils.writeDate(DataFileName.PRODUCT.toString(), json);
			}
			
		}
		//根据id查询产品
			public Product searchById(String id) throws Exception {
				ArrayList<Product> list = new ArrayList<>();
				list = findProductList();
				for(Product pk : list) {
					if(pk.getId().equals(id)) {
						return pk;
					}
				}
				return null;
			}
		//根据产品名称查询产品
			public Product searchByName(String name) throws Exception {
				ArrayList<Product> list = new ArrayList<>();
				list = findProductList();
				for(Product pk : list) {
					if(pk.getName().equals(name)) {
						return pk;
					}
				}
				return null;
			}
}
