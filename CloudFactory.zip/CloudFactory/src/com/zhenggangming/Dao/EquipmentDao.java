package com.zhenggangming.Dao;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import org.junit.Test;

import com.zhenggangming.model.Equipment;
import com.zhenggangming.utils.DataFileName;
import com.zhenggangming.utils.DataUtils;
import com.zhenggangming.utils.Json;
import com.zhenggangming.view.Product;

public class EquipmentDao {
	//保存产品类别
			public boolean saveEquipment(Equipment equipment) throws IOException {
				//把用户信息写入文件
				//把对象转换为json字符串
				String json = Json.objectToJson(equipment);
				DataUtils.writeDate(DataFileName.EQUIPMENT.toString(), json);
				return true;	
			}
		    //获取产品类别列表的方法
			public ArrayList<Equipment> findEquipmentList() throws Exception{
				String json = DataUtils.readData(DataFileName.EQUIPMENT.getName());
				//System.out.println(json);
				if(json.length()==0) {
					return null;
				}else {
					ArrayList<Equipment> equipmentList = new ArrayList<>();
					//把json字符串拆分为一个由多个json字符串组成的数组
					String[] equipments = json.split("/");
					for(String str : equipments) {
						Equipment pd = Json.jsonToObject(str, Equipment.class);
						equipmentList.add(pd);
					}
					return equipmentList;
				}
			}
			//获取id的方法，在最大id上加一，并返回
			public String getMaxId() throws Exception {
				//获得文件中所有用户信息
				ArrayList<Equipment> equipmentList = null;
				equipmentList = findEquipmentList();
				int max=0;
				if(equipmentList == null || equipmentList.size()==0)
				{
					return "1";
				}else {
					for(int i=0;i<equipmentList.size();i++)
					{
						if(Integer.parseInt(equipmentList.get(i).getId())>max) {
							max=Integer.parseInt(equipmentList.get(i).getId());
						}
					}
					String str = String.valueOf(max+1);
					return str;
				}
				
			}
			//获取产品编号----系统时间编号，精确到秒
			public String getEquipmentNumber() {
				Date now = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
				String str = "Equ-"+sdf.format(now);
				return str;
			}
			//   超级管理员删除设备
			public void deleteEquipment(ArrayList<String> list) throws Exception {
				ArrayList<Equipment> equipmentList = findEquipmentList();
				for(int i=0;i<list.size();i++) {
					for(int j=0;j<equipmentList.size();j++) {
						if(list.get(i).equals(equipmentList.get(j).getId())) {
							if(equipmentList.get(j).getRentState().equals("已被租用") || !equipmentList.get(j).getOwnerShip().equals("")) {
								continue;
							}else {
								equipmentList.remove(equipmentList.get(j));	
							}
						}
					}
				}
				DataUtils.deleteDataFile(DataFileName.EQUIPMENT.toString());
				if(equipmentList.size()==0) {
					DataUtils.createFile(DataFileName.EQUIPMENT.toString());
				}
				for(int i=0;i<equipmentList.size();i++) {
					String json = Json.objectToJson(equipmentList.get(i));
					DataUtils.writeDate(DataFileName.EQUIPMENT.toString(), json);
				}
			}
			//云工厂管理员删除设备（若删的是租用的设备，则还回去）
			public void deleteEquipment2(ArrayList<String> list,String factoryName) throws Exception {
				ArrayList<Equipment> equipmentList = findEquipmentList();
				for(int i=0;i<list.size();i++) {
					for(int j=0;j<equipmentList.size();j++) {
						if(list.get(i).equals(equipmentList.get(j).getId())) {
							if(equipmentList.get(j).getRentState().equals("已被租用")) {
								equipmentList.get(j).setRentState("未被租用");
								equipmentList.get(j).setOwnerShip("");
							}else {
								equipmentList.remove(equipmentList.get(j));	
							}
						}
					}
				}
				DataUtils.deleteDataFile(DataFileName.EQUIPMENT.toString());
				if(equipmentList.size()==0) {
					DataUtils.createFile(DataFileName.EQUIPMENT.toString());
				}
				for(int i=0;i<equipmentList.size();i++) {
					String json = Json.objectToJson(equipmentList.get(i));
					DataUtils.writeDate(DataFileName.EQUIPMENT.toString(), json);
				}
			}
			//云管理员租用设备
			public void rentEquipment(ArrayList<String> list,String factoryName) throws Exception {
				ArrayList<Equipment> equipmentList = findEquipmentList();
				for(int i=0;i<list.size();i++) {
					for(int j=0;j<equipmentList.size();j++) {
						if(list.get(i).equals(equipmentList.get(j).getId())) {
							if(equipmentList.get(j).getRentState().equals("未被租用")) {
								equipmentList.get(j).setRentState("已被租用");
								equipmentList.get(j).setOwnerShip(factoryName);
							}
						}
					}
				}
				DataUtils.deleteDataFile(DataFileName.EQUIPMENT.toString());
				if(equipmentList.size()==0) {
					DataUtils.createFile(DataFileName.EQUIPMENT.toString());
				}
				for(int i=0;i<equipmentList.size();i++) {
					String json = Json.objectToJson(equipmentList.get(i));
					DataUtils.writeDate(DataFileName.EQUIPMENT.toString(), json);
				}
			}
			//改变产品信息   如类别和状态
			public void modifyEquipment(Equipment pk) throws Exception {
				ArrayList<Equipment> equipmentList = findEquipmentList();
				for(int i=0;i<equipmentList.size();i++) {
					if(equipmentList.get(i).getId().equals(pk.getId())) {
						equipmentList.remove(i);
						equipmentList.add(i, pk);
					}
				}
				DataUtils.deleteDataFile(DataFileName.EQUIPMENT.toString());
				if(equipmentList.size()==0) {
					DataUtils.createFile(DataFileName.EQUIPMENT.toString());
				}
				for(int i=0;i<equipmentList.size();i++) {
					String json = Json.objectToJson(equipmentList.get(i));
					DataUtils.writeDate(DataFileName.EQUIPMENT.toString(), json);
				}
				
			}
			//根据id查询设备
				public Equipment searchById(String id) throws Exception {
					ArrayList<Equipment> list = new ArrayList<>();
					list = findEquipmentList();
					for(Equipment pk : list) {
						if(pk.getId().equals(id)) {
							return pk;
						}
					}
					return null;
				}
			//切换设备状态
				public void modifyEquipmentState(ArrayList<String> list) throws Exception {
					ArrayList<Equipment> equipmentList = findEquipmentList();
					Equipment eq = null;
					for(int i=0;i<list.size();i++) {
						eq = searchById(list.get(i));
						for(int j=0;j<equipmentList.size();j++) {
							if(list.get(i).equals(equipmentList.get(j).getId())) {
								if(eq.getEquipmentState().equals("关机")) {
									eq.setEquipmentState("闲置中");
								}else if(eq.getEquipmentState().equals("闲置中")) {
									eq.setEquipmentState("生产中");
								}else if(eq.getEquipmentState().equals("生产中")) {
									eq.setEquipmentState("关机");
								}
								equipmentList.remove(j);
								equipmentList.add(j, eq);
								System.out.println(equipmentList.get(j).getEquipmentState());
							}
						}
					}
					DataUtils.deleteDataFile(DataFileName.EQUIPMENT.toString());
					if(equipmentList.size()==0) {
						DataUtils.createFile(DataFileName.EQUIPMENT.toString());
					}
					for(int i=0;i<equipmentList.size();i++) {
						String json = Json.objectToJson(equipmentList.get(i));
						DataUtils.writeDate(DataFileName.EQUIPMENT.toString(), json);
					}
					
				}
				//根据工厂名称获得工厂中所有的设备
				public ArrayList<Equipment> getFactoryEquipmentList(String factoryName) throws Exception {
					ArrayList<Equipment> list1 = findEquipmentList();
					ArrayList<Equipment> list2 = new ArrayList<Equipment>();
					for(Equipment ep : list1) {
						if(ep.getOwnerShip().equals(factoryName)) {
							list2.add(ep);
						}
					}
					return list2;
				}
				//获取产能中心所有未被租用的设备
				public ArrayList<Equipment> getUnrentList() throws Exception {
					ArrayList<Equipment> list1 = findEquipmentList();
					ArrayList<Equipment> list2 = new ArrayList<Equipment>();
					for(Equipment ep : list1) {
						if(ep.getRentState().equals("未被租用")) {
							list2.add(ep);
						}
					}
					return list2;
				}
				//为设备添加产能
				public void addOrder(Equipment ep) {
					
				}
				//通过更新数据，来达到增加产能
				public void addCapacity(Equipment ep) throws Exception {
					ArrayList<Equipment> list1 = findEquipmentList();
					for(int i=0;i<list1.size();i++) {
						if(list1.get(i).getId().equals(ep.getId())) {
							 list1.remove(i);
							 list1.add(i, ep);
						}
					}
					DataUtils.deleteDataFile(DataFileName.EQUIPMENT.toString());
					if(list1.size()==0) {
						DataUtils.createFile(DataFileName.EQUIPMENT.toString());
					}
					for(int i=0;i<list1.size();i++) {
						String json = Json.objectToJson(list1.get(i));
						DataUtils.writeDate(DataFileName.EQUIPMENT.toString(), json);
					}
				}
}
