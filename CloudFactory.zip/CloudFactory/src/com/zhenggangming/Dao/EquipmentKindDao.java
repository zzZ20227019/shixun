package com.zhenggangming.Dao;

import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import com.zhenggangming.Dao.EquipmentDao;
import com.zhenggangming.controller.EquipmentController;
import com.zhenggangming.model.Equipment;
import com.zhenggangming.model.EquipmentKind;
import com.zhenggangming.utils.DataFileName;
import com.zhenggangming.utils.DataUtils;
import com.zhenggangming.utils.Json;

public class EquipmentKindDao {
	//保存产品类别
		public boolean saveEquipmentKind(EquipmentKind equipmentKind) throws IOException {
			//把用户信息写入文件
			//把对象转换为json字符串
			String json = Json.objectToJson(equipmentKind);
			DataUtils.writeDate(DataFileName.EQUIPMENTTYPE.toString(), json);
			return true;	
		}
	    //获取产品类别列表的方法
		public ArrayList<EquipmentKind> findEquipmentKindList() throws Exception{
			String json = DataUtils.readData(DataFileName.EQUIPMENTTYPE.getName());
			//System.out.println(json);
			if(json.length()==0) {
				return null;
			}else {
				ArrayList<EquipmentKind> equipmentKindList = new ArrayList<>();
				//把json字符串拆分为一个由多个json字符串组成的数组
				String[] equipmentKinds = json.split("/");
				for(String str : equipmentKinds) {
					EquipmentKind pd = Json.jsonToObject(str, EquipmentKind.class);
					equipmentKindList.add(pd);
				}
				return equipmentKindList;
			}
		}
		//获取id的方法，在最大id上加一，并返回
		public String getMaxId() throws Exception {
			//获得文件中所有用户信息
			ArrayList<EquipmentKind> equipmentKindList = null;
			equipmentKindList = findEquipmentKindList();
			int max=0;
			if(equipmentKindList == null || equipmentKindList.size()==0)
			{
				return "1";
			}else {
				for(int i=0;i<equipmentKindList.size();i++)
				{
					if(Integer.parseInt(equipmentKindList.get(i).getId())>max) {
						max=Integer.parseInt(equipmentKindList.get(i).getId());
					}
				}
				String str = String.valueOf(max+1);
				return str;
			}
			
		}
		//删除产品类别
		public void deleteEquipmentKind(ArrayList<String> list) throws Exception {
			ArrayList<EquipmentKind> EquipmentKindList = findEquipmentKindList();
			for(int i=0;i<list.size();i++) {
				for(int j=0;j<EquipmentKindList.size();j++) {
					if(list.get(i).equals(EquipmentKindList.get(j).getId())) {
						if(!EquipmentController.getInstance().isRent(EquipmentKindList.get(j).getName()))
								EquipmentKindList.remove(EquipmentKindList.get(j));
						}					}
				
			}
			DataUtils.deleteDataFile(DataFileName.EQUIPMENTTYPE.toString());
			if(EquipmentKindList.size()==0) {
				DataUtils.createFile(DataFileName.EQUIPMENTTYPE.toString());
			}
			for(int i=0;i<EquipmentKindList.size();i++) {
				String json = Json.objectToJson(EquipmentKindList.get(i));
				DataUtils.writeDate(DataFileName.EQUIPMENTTYPE.toString(), json);
			}
		}
		//改变产品类别
		public void modifyEquipmentKind(EquipmentKind pk) throws Exception {
			ArrayList<EquipmentKind> EquipmentKindList = findEquipmentKindList();
			for(int i=0;i<EquipmentKindList.size();i++) {
				if(EquipmentKindList.get(i).getId().equals(pk.getId())) {
					EquipmentKindList.remove(i);
					EquipmentKindList.add(i, pk);
				}
			}
			DataUtils.deleteDataFile(DataFileName.EQUIPMENTTYPE.toString());
			if(EquipmentKindList.size()==0) {
				DataUtils.createFile(DataFileName.EQUIPMENTTYPE.toString());
			}
			for(int i=0;i<EquipmentKindList.size();i++) {
				String json = Json.objectToJson(EquipmentKindList.get(i));
				DataUtils.writeDate(DataFileName.EQUIPMENTTYPE.toString(), json);
			}
			
		}
		//根据id查询产品类别
			public EquipmentKind searchById(String id) throws Exception {
				ArrayList<EquipmentKind> list = new ArrayList<>();
				list = findEquipmentKindList();
				for(EquipmentKind pk : list) {
					if(pk.getId().equals(id)) {
						return pk;
					}
				}
				return null;
			}
}
