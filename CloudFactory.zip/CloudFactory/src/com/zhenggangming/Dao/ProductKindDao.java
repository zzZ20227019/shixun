package com.zhenggangming.Dao;

import java.io.IOException;
import java.util.ArrayList;

import com.zhenggangming.model.ProductKind;
import com.zhenggangming.model.User;
import com.zhenggangming.utils.DataFileName;
import com.zhenggangming.utils.DataUtils;
import com.zhenggangming.utils.Json;

public class ProductKindDao {

	//保存产品类别
	public boolean saveProductKind(ProductKind productKind) throws IOException {
		//把用户信息写入文件
		//把对象转换为json字符串
		String json = Json.objectToJson(productKind);
		DataUtils.writeDate(DataFileName.PRODUCTMSG.toString(), json);
		return true;	
	}
    //获取产品类别列表的方法
	public ArrayList<ProductKind> findProductKindList() throws Exception{
		String json = DataUtils.readData(DataFileName.PRODUCTMSG.getName());
		//System.out.println(json);
		if(json.length()==0) {
			return null;
		}else {
			ArrayList<ProductKind> productKindList = new ArrayList<>();
			//把json字符串拆分为一个由多个json字符串组成的数组
			String[] productKinds = json.split("/");
			for(String str : productKinds) {
				ProductKind pd = Json.jsonToObject(str, ProductKind.class);
				productKindList.add(pd);
			}
			return productKindList;
		}
	}
	//获取id的方法，在最大id上加一，并返回
	public String getMaxId() throws Exception {
		//获得文件中所有用户信息
		ArrayList<ProductKind> productKindList = null;
		productKindList = findProductKindList();
		int max=0;
		if(productKindList == null || productKindList.size()==0)
		{
			return "1";
		}else {
			for(int i=0;i<productKindList.size();i++)
			{
				if(Integer.parseInt(productKindList.get(i).getId())>max) {
					max=Integer.parseInt(productKindList.get(i).getId());
				}
			}
			String str = String.valueOf(max+1);
			return str;
		}
		
	}
	//删除产品类别
	public void deleteProductKind(ArrayList<String> list) throws Exception {
		ArrayList<ProductKind> productKindList = findProductKindList();
		for(int i=0;i<list.size();i++) {
			for(int j=0;j<productKindList.size();j++) {
				if(list.get(i).equals(productKindList.get(j).getId())) {
					productKindList.remove(productKindList.get(j));
				}
			}
		}
		DataUtils.deleteDataFile(DataFileName.PRODUCTMSG.toString());
		if(productKindList.size()==0) {
			DataUtils.createFile(DataFileName.PRODUCTMSG.toString());
		}
		for(int i=0;i<productKindList.size();i++) {
			String json = Json.objectToJson(productKindList.get(i));
			DataUtils.writeDate(DataFileName.PRODUCTMSG.toString(), json);
		}
	}
	//改变产品类别
	public void modifyProductKind(ProductKind pk) throws Exception {
		ArrayList<ProductKind> ProductKindList = findProductKindList();
		for(int i=0;i<ProductKindList.size();i++) {
			if(ProductKindList.get(i).getId().equals(pk.getId())) {
				ProductKindList.remove(i);
				ProductKindList.add(i, pk);
			}
		}
		DataUtils.deleteDataFile(DataFileName.PRODUCTMSG.toString());
		if(ProductKindList.size()==0) {
			DataUtils.createFile(DataFileName.PRODUCTMSG.toString());
		}
		for(int i=0;i<ProductKindList.size();i++) {
			String json = Json.objectToJson(ProductKindList.get(i));
			DataUtils.writeDate(DataFileName.PRODUCTMSG.toString(), json);
		}
		
	}
	//根据id查询产品类别
		public ProductKind searchById(String id) throws Exception {
			ArrayList<ProductKind> list = new ArrayList<>();
			list = findProductKindList();
			for(ProductKind pk : list) {
				if(pk.getId().equals(id)) {
					return pk;
				}
			}
			return null;
		}
}
