package com.zhenggangming.Dao;

import java.awt.List;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import com.zhenggangming.model.User;
import com.zhenggangming.utils.DataFileName;
import com.zhenggangming.utils.DataUtils;
import com.zhenggangming.utils.Json;

/**
 * 完成对用户各种操作
 * @author 11642
 *
 */



public class UserDao {

	private User superController = new User("","admin","123",null,null,null,null, null, null, null);
	//添加用户信息
	public boolean saveUser(User user) throws IOException
	{
		//把用户信息写入文件
		//把对象转换为json字符串
		String json = Json.objectToJson(user);
		DataUtils.writeDate(DataFileName.USER.toString(), json);
		return true;
	}
	//获取用户列表的方法
	public ArrayList<User> findUserList() throws Exception{
		String json = DataUtils.readData(DataFileName.USER.getName());
		//System.out.println(json);
		if(json.length()==0) {
			return null;
		}else {
			ArrayList<User> userList = new ArrayList<>();
			//把json字符串拆分为一个由多个json字符串组成的数组
			String[] users = json.split("/");
			for(String str : users) {
				User user = Json.jsonToObject(str, User.class);
				userList.add(user);
			}
			return userList;
		}
	}
	//获取所有云工厂列表
	public ArrayList<User> findFactoryList() throws Exception{
		ArrayList<User> list1 = new ArrayList<User>();
		ArrayList<User> list2 = findUserList();
		for(User u : list2) {
			if(u.getPower().equals("云工厂")) {
				list1.add(u);
			}
		}
		return list1;
	}
	//获取id的方法，在最大id上加一，并返回
	public String getMaxId() throws Exception {
		//获得文件中所有用户信息
		ArrayList<User> userList = null;
		userList = findUserList();
		int max=0;
		if(userList == null || userList.size()==0)
		{
			return "1";
		}else {
			for(int i=0;i<userList.size();i++)
			{
				if(Integer.parseInt(userList.get(i).getId())>max) {
					max=Integer.parseInt(userList.get(i).getId());
				}
			}
			String str = String.valueOf(max+1);
			return str;
		}
		
	}
	//判断用户名是否可用
	public boolean isUse(String loginName) throws Exception {
		ArrayList<User> userList = findUserList();
//		for(User user : userList) {
//			if(loginName.equals(user.getAccount()))
//			{
//				return false;
//			}
//	}
		boolean flag = userList.stream().noneMatch(t->t.getAccount().equals(loginName));
		return flag;
	
	}

	//判断登录用户的身份
	public User judgeIdentity(String loginName, String password) throws Exception {
		if(superController.getAccount().equals(loginName) && superController.getPassword().equals(password)) {
			return superController;
		}
	    ArrayList<User> userList = findUserList();
	    for(User user : userList) {
	    	if(user.getAccount().equals(loginName) && user.getPassword().equals(password)) {
	    		return user;
	    	}
	    }
		return null;
	}
	//删除用户
	public void deleteUser(ArrayList<String> list) throws Exception {
		ArrayList<User> userList = findUserList();
		for(int i=0;i<list.size();i++) {
			for(int j=0;j<userList.size();j++) {
				if(list.get(i).equals(userList.get(j).getId())) {
					userList.remove(userList.get(j));
				}
			}
		}
		DataUtils.deleteDataFile(DataFileName.USER.toString());
		if(userList.size()==0) {
			DataUtils.createFile(DataFileName.USER.toString());
		}
		for(int i=0;i<userList.size();i++) {
			String json = Json.objectToJson(userList.get(i));
			DataUtils.writeDate(DataFileName.USER.toString(), json);
		}
	}
	//根据id查询用户
	public User searchById(String id) throws Exception {
		ArrayList<User> list = new ArrayList<>();
		list = findUserList();
		for(User user : list) {
			if(user.getId().equals(id)) {
				return user;
			}
		}
		return null;
	}
	//根据name查找用户
	public User searchByName(String name) throws Exception {
		ArrayList<User> list = new ArrayList<>();
		list = findUserList();
		for(User user : list) {
			if(user.getFactoryName().equals(name)) {
				return user;
			}
		}
		return null;
	}
//	public static ArrayList<User> change(ArrayList<User> list, User u1, User u2) {
//        int i = list.indexOf(u1);
//        boolean remove = list.remove(u1);
//        list.add(i,u2);
//        return list;
//    }
	//修改用户信息
	public void modifyUser(User user) throws Exception {
		ArrayList<User> userList = findUserList();
		for(int i=0;i<userList.size();i++) {
			if(userList.get(i).getId().equals(user.getId())) {
				userList.remove(i);
				userList.add(i, user);
			}
		}
		DataUtils.deleteDataFile(DataFileName.USER.toString());
		if(userList.size()==0) {
			DataUtils.createFile(DataFileName.USER.toString());
		}
		for(int i=0;i<userList.size();i++) {
			String json = Json.objectToJson(userList.get(i));
			DataUtils.writeDate(DataFileName.USER.toString(), json);
		}
		
	}
	//修改工厂状态
	public void setFactoryState(String id) throws Exception {
		ArrayList<User> list = findUserList();
		for(int i=0;i<list.size();i++) {
			if(list.get(i).getId().equals(id)) {
				if(list.get(i).getState().equals("关停")) {
					list.get(i).setState("开启");
				}else if(list.get(i).getState().equals("开启")) {
					list.get(i).setState("关停");
				}
			}
		}
		DataUtils.deleteDataFile(DataFileName.USER.toString());
		if(list.size()==0) {
			DataUtils.createFile(DataFileName.USER.toString());
		}
		for(int i=0;i<list.size();i++) {
			String json = Json.objectToJson(list.get(i));
			DataUtils.writeDate(DataFileName.USER.toString(), json);
		}
		
	}
	
	
}
