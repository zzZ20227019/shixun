package com.zhenggangming.utils;

import java.util.ArrayList;

import javax.swing.table.AbstractTableModel;

import com.zhenggangming.controller.OrderController;
import com.zhenggangming.model.Order;
import com.zhenggangming.model.User;


public class OrderTable4 extends AbstractTableModel{
	private String[] columnNames = {" ","ID","订单编号","产品名称","订单数量","交付日期","投标截止日期","收货人","收货人联系方式","订单状态"};
	private Object[][] data;
	private OrderController orderController = OrderController.getInstance();
	/**
	 * 构造方法，初始化二维data对应的数组
	 * @throws Exception 
	 */

	public OrderTable4(String orderState,User user) throws Exception {
		ArrayList<Order> list = orderController.getZhongBiaoList(orderState,user);
	    if(list==null) {
	    	data = new Object[0][0];
	    }else {
	    	data = new Object[list.size()][10];
	    	for(int i=0;i<list.size();i++) {
	    		data[i][0] = new Boolean(false);
	    		data[i][1] = list.get(i).getId();
	    		data[i][2] = list.get(i).getSerialNumber();
	    		data[i][3] = list.get(i).getName();
	    		data[i][4] = list.get(i).getNumber();
	    		data[i][5] = list.get(i).getJiaoFuDate();
	    		data[i][6] = list.get(i).getTouBiaoEndDate();
	    		data[i][7] = list.get(i).getReceiver();
	    		data[i][8] = list.get(i).getPhone();
	    		data[i][9] = list.get(i).getOrderState();
	    	}
	    }
	}
	/**
	 * 得到指定列的数据类型
	 */
	public Class<?> getColumnClass(int columnIndex){
		return data[0][columnIndex].getClass();
	}
	/**
	 * 得到表格行数
	 */
	@Override
	public int getRowCount() {
		return data.length;
	}
    /**
     * 得到表格列数
     */
	@Override
	public int getColumnCount() {
		return columnNames.length;
	}
    /**
     * 得到数据所对应对象
     */
	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		return data[rowIndex][columnIndex];
	}
	/**
	 * 得到列名
	 */
	public String getColumnName(int column) {
		return columnNames[column];
	}
    /**
     * 指定设置书单元是否可编辑，这里设置“姓名”“学号”不可编辑
     */
	public boolean isCellEditable(int rowIndex,int columnIndex) {
		if(columnIndex != 1&&columnIndex!=8&&columnIndex!=9) {
			return true;
		}else {
			return false;
		}
	}
	/**
	 * 如果数据单元为可编辑，则将编辑后的值替换原来的值
	 */
	public void setValueAt(Object aValue,int rowIndex,int columnIndex) {
		data[rowIndex][columnIndex] = aValue;
		//通知监听器数据单元已经改变
		fireTableCellUpdated(rowIndex,columnIndex);
	}

}

