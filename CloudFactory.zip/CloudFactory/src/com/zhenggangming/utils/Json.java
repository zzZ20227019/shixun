package com.zhenggangming.utils;

import java.util.List;

import com.alibaba.fastjson.JSONObject;

/**
 * json处理类
 * @author 11642
 *
 */
public class Json {
    //把json字符串转换成对象
	public static <T> T jsonToObject(String json,Class<T> clazz) {
		if(json == null||json.length()==0) {
			return null;
		} 
		System.out.println(json);
		T t = JSONObject.parseObject(json,clazz);
		return t;
	}
	//把对象转换成json字符串
	public static String objectToJson(Object o) {
		if(o == null) {
			return null;
		}
		return JSONObject.toJSONString(o);
	}
	//把json字符串转换为list集合
	public static <T>List<T> jsonToList(String json,Class<T> clazz){
		if(json == null||json.length()==0) {
			return null;
		}
		List<T> list = JSONObject.parseArray(json, clazz);
		return list;
	}
	//把list集合转换为json字符串
	public static <T> String ArrayToJson(List<T> list) {
		if(list==null || list.size()==0) {
			return null;
		}
		return JSONObject.toJSONString(list);
		}
}
