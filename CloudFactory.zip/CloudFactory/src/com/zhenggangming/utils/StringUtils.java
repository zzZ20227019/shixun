package com.zhenggangming.utils;

public class StringUtils {
    //字符串非空判断
	public static boolean isEmpty(String str) {
		if(str == null || str.length()==0) {
			return true;
		}else {
			return false;
		}
	}
}
