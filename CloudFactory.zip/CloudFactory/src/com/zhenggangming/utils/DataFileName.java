package com.zhenggangming.utils;

public enum DataFileName {
    USER("user"),
    PRODUCT("product"),
    PRODUCTMSG("productmsg"),
    EQUIPMENTTYPE("equipmenttype"),
    EQUIPMENT("equipment"),
	ORDER("order"),
	/*BID("bid")*/;
	private String name;
	private DataFileName(String name) {
		this.name = name;
	}
	public String getName()
	{
		return name;
	}
}
