package com.zhenggangming.utils;

import java.util.regex.Pattern;

import com.zhenggangming.Dao.UserDao;
import com.zhenggangming.model.User;

public class UserDataValidate {
    public static String UserDateValidate1(User user) throws Exception {
    	String loginName = user.getAccount();
    	//登录名
    	if(StringUtils.isEmpty(loginName))
    	{
    		return "用户名不能为空";
    	}
    	if(!loginName.matches("\\w{3,20}")) {
    		return "登录名必须在3-20位合法字符 ";
    	}
    	//判断用户名是否可用
    	if(!isUse(loginName)) {
    		return "该用户名已经存在，请更换";
    	}
    	return "";
    }
    public static String UserDateValidate2(User user) throws Exception {
    	String loginPassword = user.getPassword();
    	Pattern pattern = Pattern.compile("[0-9]*"); 
    	//密码
    	if(StringUtils.isEmpty(loginPassword))
    	{
    		return "密码不能为空";
    	}
    	if(loginPassword.length()<3 || loginPassword.length()>12 || !pattern.matcher(loginPassword).matches()) { 
    		return "密码必须是3-12的数字 ";
    	}
    	return "";
    }
    public static String UserDateValidate3(User user) throws Exception {
    	String loginPhone = user.getPhone();
    	Pattern pattern = Pattern.compile("[0-9]*"); 
    	//登录名
    	if(StringUtils.isEmpty(loginPhone))
    	{
    		return "联系方式不能为空";
    	}else if(loginPhone.length()!=11 || !pattern.matcher(loginPhone).matches()) { 
    		return "联系方式必须是11位的数字 ";
    	}
    	
    	return "";
    }
    public static boolean isUse(String loginName) throws Exception
    {
    	UserDao dao = new UserDao();
    	return dao.isUse(loginName);
    	
    }
}
