package com.zhenggangming.utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URLDecoder;

/**
 * 文件操作工具的方法大多数定义成静态,方便调用
 * @author 11642
 *
 */
public class DataUtils {
	//读取文件信息
    public static String readData(String fileName) throws Exception {
    	StringBuffer sb = null;
    	//工厂下的bin目录
    	String path = System.getProperty("user.dir")+File.separator+"src"+File.separator+fileName+".txt";
    	path = URLDecoder.decode(path);
    	sb = new StringBuffer();
    	File file = new File(path);
    	if(!file.exists())
    	{
    		try {
				file.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	}
    	FileReader fr = new FileReader(file);
    	BufferedReader br = new BufferedReader(fr);
    	String msg = br.readLine();
    	while(msg!=null) {
    		sb.append(msg+"/");
    		msg = br.readLine();
    	}
    	fr.close();
    	br.close();
    	return sb.toString();
    }
    //向文件中写入信息
    public static void writeDate(String fileName,String json) throws IOException {
    	String path = System.getProperty("user.dir")+File.separator+"src"+File.separator+fileName+".txt";
    	path = URLDecoder.decode(path);
    	System.out.println(path);
    	File file = new File(path);
    	FileWriter fw = new FileWriter(file,true);
    	BufferedWriter bw = new BufferedWriter(fw);
    	bw.write(json);
    	bw.newLine();
    	bw.flush();
    	bw.close();
    	fw.close();
    }
    //删除原文件
	public static void deleteDataFile(String fileName) {
		String path = System.getProperty("user.dir")+File.separator+"src"+File.separator+fileName+".txt";
    	path = URLDecoder.decode(path);
    	File file = new File(path);
    	file.delete();
	}
	//创造新文件
	public static void createFile(String fileName) throws IOException {
		String path = System.getProperty("user.dir")+File.separator+"src"+File.separator+fileName+".txt";
    	path = URLDecoder.decode(path);
		File file = new File(path);
		file.createNewFile();
	}
}
