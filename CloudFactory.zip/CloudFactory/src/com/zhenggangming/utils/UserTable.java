package com.zhenggangming.utils;

import java.util.ArrayList;

import javax.swing.table.AbstractTableModel;

import com.zhenggangming.controller.UserController;
import com.zhenggangming.model.User;

public class UserTable extends AbstractTableModel {

	private String[] columnNames = {" ","ID","登陆账号","姓名","联系方式","角色名称"};
	private Object[][] data;
	private UserController userController = UserController.getInstance();
	/**
	 * 构造方法，初始化二维data对应的数组
	 * @throws Exception 
	 */

	public UserTable(String name) throws Exception {
		ArrayList<User> list = userController.getList(name);
	    if(list==null) {
	    	data = new Object[0][0];
	    }else {
	    	data = new Object[list.size()][6];
	    	for(int i=0;i<list.size();i++) {
	    		data[i][0] = new Boolean(false);
	    		data[i][1] = list.get(i).getId();
	    		data[i][2] = list.get(i).getAccount();
	    		data[i][3] = list.get(i).getUserName();
	    		data[i][4] = list.get(i).getPhone();
	    		data[i][5] = list.get(i).getPower();
	    	}
	    }
	}
	/**
	 * 得到指定列的数据类型
	 */
	public Class<?> getColumnClass(int columnIndex){
		return data[0][columnIndex].getClass();
	}
	/**
	 * 得到表格行数
	 */
	@Override
	public int getRowCount() {
		return data.length;
	}
    /**
     * 得到表格列数
     */
	@Override
	public int getColumnCount() {
		return columnNames.length;
	}
    /**
     * 得到数据所对应对象
     */
	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		return data[rowIndex][columnIndex];
	}
	/**
	 * 得到列名
	 */
	public String getColumnName(int column) {
		return columnNames[column];
	}
    /**
     * 指定设置书单元是否可编辑，这里设置“姓名”“学号”不可编辑
     */
	public boolean isCellEditable(int rowIndex,int columnIndex) {
		if(columnIndex != 1&&columnIndex!=8&&columnIndex!=9) {
			return true;
		}else {
			return false;
		}
	}
	/**
	 * 如果数据单元为可编辑，则将编辑后的值替换原来的值
	 */
	public void setValueAt(Object aValue,int rowIndex,int columnIndex) {
		data[rowIndex][columnIndex] = aValue;
		//通知监听器数据单元已经改变
		fireTableCellUpdated(rowIndex,columnIndex);
	}
}
