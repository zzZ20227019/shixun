package com.zhenggangming.controller;

import java.util.ArrayList;

import com.zhenggangming.Dao.ProductDao;
import com.zhenggangming.model.Product;



public class ProductController {
	private static ProductDao productDao = new ProductDao();
	private static ProductController productController = new ProductController();
	public static ProductController getInstance() {
		return productController;
	}
	//注册新的产品类别
	public boolean register(Product product) throws Exception {
		String id = productDao.getMaxId();
		String serialNumber = productDao.getProductNumber();
		product.setSerialNumber(serialNumber);
		product.setId(id);
		productDao.saveProduct(product);
		return true;
	}
	//删除产品类别
	public static void deleteProduct(ArrayList<String> list) throws Exception {
		productDao.deleteProduct(list);	
    }
	//修改产品类别
	public void modifyProduct(Product pk) throws Exception {
		productDao.modifyProduct(pk);	
	}
	//获取全部产品列表  或   根据姓名获取产品列表
	public ArrayList<Product> getList(String name) throws Exception {
		if(name == null) {
			return productDao.findProductList();
		}else {
			for(Product pk : productDao.findProductList()) {
				if(pk.getName().equals(name)) {
					ArrayList<Product> list = new ArrayList<>();
					list.add(pk);
					return list;
				}
			}
		}
		return null;
	}
	//根据id获取产品
		public Product searchById(String id) throws Exception {
			return productDao.searchById(id);
		}
	//根据产品名称获得产品
		public Product searchByName(String name) throws Exception {
			return productDao.searchByName(name);
		}
}
