package com.zhenggangming.controller;

import java.io.IOException;
import java.util.ArrayList;

import com.zhenggangming.Dao.UserDao;
import com.zhenggangming.model.User;


public class UserController {

	private static UserDao userDao = new UserDao();
	private static UserController userController = new UserController();
	public static UserController getInstance() {
		return userController;
	}
	 //注册新的用户
	public boolean register(User user) throws Exception {
		String id = userDao.getMaxId();
		user.setId(id);
		userDao.saveUser(user);
		return true;
	}
	//登录
	public User login(String loginName,String password) throws Exception {
		UserDao userDao = new UserDao();
		User user = userDao.judgeIdentity(loginName,password);
		return user;
	}
	//删除用户
	public static void deleteUser(ArrayList<String> list) throws Exception {
		userDao.deleteUser(list);	
	}
	//获取全部用户列表  或   根据姓名获取用户列表
	public ArrayList<User> getList(String name) throws Exception {
		if(name == null) {
			return userDao.findUserList();
		}else {
			for(User user : userDao.findUserList()) {
				if(user.getAccount().equals(name)) {
					ArrayList<User> list = new ArrayList<>();
					list.add(user);
					return list;
				}
			}
		}
		return null;
	}
	//通过名字查找一个用户
	public User searchByName(String name) throws Exception {
		return userDao.searchByName(name);
	}
	//获取全部的云工厂列表
	public ArrayList<User> getFactoryList(String name) throws Exception {
		if(name == null) {
			return userDao.findFactoryList();
		}else {
			for(User user : userDao.findFactoryList()) {
				if(user.getFactoryName().equals(name)) {
					ArrayList<User> list = new ArrayList<>();
					list.add(user);
					return list;
				}
			}
		}
		return null;
	}
	//根据id获取用户
	public User searchById(String id) throws Exception {
		return userDao.searchById(id);
	}
	//修改用户信息
	public void modify(User user) throws Exception {
		userDao.modifyUser(user);
		
	}
	//修改工厂状态
	public void setFactoryState(String id) throws Exception {
		userDao.setFactoryState(id);
		
	}
}
