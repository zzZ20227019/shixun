package com.zhenggangming.controller;

import java.util.ArrayList;
import java.util.HashMap;

import com.zhenggangming.Dao.EquipmentDao;
import com.zhenggangming.model.Equipment;
import com.zhenggangming.model.Product;

public class EquipmentController {
	private static EquipmentDao equipmentDao = new EquipmentDao();
	private static EquipmentController equipmentController = new EquipmentController();
	public static EquipmentController getInstance() {
		return equipmentController;
	}
	//注册新的设备类别
	public boolean register(Equipment equipment) throws Exception {
		String id = equipmentDao.getMaxId();
		String serialNumber = equipmentDao.getEquipmentNumber();
		equipment.setSerialNumber(serialNumber);
		equipment.setId(id);
		equipmentDao.saveEquipment(equipment);
		return true;
	}
	//删除设备类别
	public static void deleteEquipment(ArrayList<String> list) throws Exception {
		equipmentDao.deleteEquipment(list);	
    }
	//切换设备状态
	public void modifyEquipmentState(ArrayList<String> list) throws Exception {
		equipmentDao.modifyEquipmentState(list);
	}
	//修改设备信息  
	public void modifyEquipment(Equipment pk) throws Exception {
		equipmentDao.modifyEquipment(pk);	
	}
	//获取全部设备列表  或   根据设备姓名获取设备列表
	public ArrayList<Equipment> getList(String name) throws Exception {
		if(name == null) {
			return equipmentDao.findEquipmentList();
		}else {
			for(Equipment pk : equipmentDao.findEquipmentList()) {
				if(pk.getName().equals(name)) {
					ArrayList<Equipment> list = new ArrayList<>();
					list.add(pk);
					return list;
				}
			}
		}
		return null;
	}
	//根据工厂名称获得工厂中所有的设备
	public static ArrayList<Equipment> getFactoryEquipmentList(String factoryName) throws Exception{
		return equipmentDao.getFactoryEquipmentList(factoryName);
	}
	//获取产能中心所有未被租用的设备
	public ArrayList<Equipment> getUnrentList() throws Exception{
		return equipmentDao.getUnrentList();
	}
	//根据id获取设备
		public Equipment searchById(String id) throws Exception {
			return equipmentDao.searchById(id);
		}
	//判断该类型的设备是否被租用
		public boolean isRent(String name) throws Exception {
			ArrayList<Equipment> list = equipmentDao.findEquipmentList();
			for(Equipment ep : list) {
				if(ep.getKind().equals(name) && ep.getRentState().equals("租用")) {
					return true;
				}
			}
			return false;
		}
	//云工厂管理员删除设备（若是租用的设备，则返回给产能中心）
		public void deleteEquipment2(ArrayList<String> list,String factoryName) throws Exception {
			equipmentDao.deleteEquipment2(list, factoryName);
		}
	//云工厂管理员租用设备
		public void rentEquipment(ArrayList<String> list, String factoryName) throws Exception {
			equipmentDao.rentEquipment(list, factoryName);
		}
	//通过id获得要增加产能的设备的产能
		public HashMap<Product, Integer> getCapacityById(String id) throws Exception {
			return equipmentDao.searchById(id).getCapacity();		
		}
	//通过更新数据，来达到增加产能
		public static void addCapacity(Equipment ep) throws Exception {
			equipmentDao.addCapacity(ep);
			
		}
}
