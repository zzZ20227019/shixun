package com.zhenggangming.controller;

import java.util.ArrayList;

import com.zhenggangming.Dao.EquipmentKindDao;
import com.zhenggangming.model.EquipmentKind;

public class EquipmentKindController {
	private static EquipmentKindDao EquipmentKindDao = new EquipmentKindDao();
	private static EquipmentKindController equipmentKindController = new EquipmentKindController();
	public static EquipmentKindController getInstance() {
		return equipmentKindController;
	}
	//注册新的产品类别
	public boolean register(EquipmentKind EquipmentKind) throws Exception {
		String id = EquipmentKindDao.getMaxId();
		EquipmentKind.setId(id);
		EquipmentKindDao.saveEquipmentKind(EquipmentKind);
		return true;
	}
	//删除产品类别
	public static void deleteEquipmentKind(ArrayList<String> list) throws Exception {
		EquipmentKindDao.deleteEquipmentKind(list);	
    }
	//修改产品类别
	public void modifyEquipmentKind(EquipmentKind pk) throws Exception {
		EquipmentKindDao.modifyEquipmentKind(pk);	
	}
	//获取全部产品类别列表  或   根据姓名获取产品类别列表
	public ArrayList<EquipmentKind> getList(String name) throws Exception {
		if(name == null) {
			return EquipmentKindDao.findEquipmentKindList();
		}else {
			for(EquipmentKind pk : EquipmentKindDao.findEquipmentKindList()) {
				if(pk.getName().equals(name)) {
					ArrayList<EquipmentKind> list = new ArrayList<>();
					list.add(pk);
					return list;
				}
			}
		}
		return null;
	}
	//根据id获取产品类别
		public EquipmentKind searchById(String id) throws Exception {
			return EquipmentKindDao.searchById(id);
		}
}
