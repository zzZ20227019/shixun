package com.zhenggangming.controller;

import java.util.ArrayList;
import java.util.HashMap;

import com.zhenggangming.Dao.OrderDao;
import com.zhenggangming.model.Order;
import com.zhenggangming.model.Product;
import com.zhenggangming.model.User;

public class OrderController {
	private static OrderDao orderDao = new OrderDao();
	private static OrderController orderController = new OrderController();
	public static OrderController getInstance() {
		return orderController;
	}
	//注册新的订单
	public boolean register(Order order) throws Exception {
		String id = orderDao.getMaxId();
		String serialNumber = orderDao.getOrderNumber();
		order.setSerialNumber(serialNumber);
		order.setId(id);
		orderDao.saveOrder(order);
		return true;
	}
	//删除设备类别
	public static void deleteOrder(ArrayList<String> list) throws Exception {
		orderDao.deleteOrder(list);	
    }
	//切换设备状态
	public void modifyOrderState(ArrayList<String> list) throws Exception {
		orderDao.modifyOrderState(list);
	}
	//修改设备信息  
	public void modifyOrder(Order pk) throws Exception {
		orderDao.modifyOrder(pk);	
	}
	//获取全部设备列表  或   根据设备姓名获取设备列表
	public ArrayList<Order> getList(String name) throws Exception {
		if(name == null) {
			return orderDao.findOrderList();
		}else {
			for(Order pk : orderDao.findOrderList()) {
				if(pk.getName().equals(name)) {
					ArrayList<Order> list = new ArrayList<>();
					list.add(pk);
					return list;
				}
			}
		}
		return null;
	}
	//设置中标工厂
	public void setZhongBiaoFactory(User user,String orderNumber) throws Exception {
		orderDao.setZhongBiaoFactory(user, orderNumber);
	}

	
	//根据factoryName获取订单
	    public ArrayList<Order> searchByFactoryId(String factoryId) throws Exception {
	    	return orderDao.searchByFactoryId(factoryId);
	    }
	//根据ordernumber获取订单
		public Order searchByOrderNumber(String orderNumber) throws Exception {
			return orderDao.searchByOrderNumber(orderNumber);
		}
	//判断该订单的设备是否被修改
		public boolean isChangeable(String id) throws Exception {
			ArrayList<Order> list = orderDao.findOrderList();
			for(Order ep : list) {
				if(ep.getId().equals(id) && !ep.getOrderState().equals("保存")) {
					return false;
				}
			}
			return true;
		}

		public Order searchById(String id) throws Exception {
			
			return orderDao.searchById(id);
		}
		
		//通过订单状态来获取订单列表
		public ArrayList<Order> getListByOrderState(String orderState) throws Exception {
			
			return orderDao.getListByOrderState(orderState);
		}
		//判断订单是否为已发货
				public boolean IsFaHuo(String orderNumber) throws Exception {
					return orderDao.IsFaHuo(orderNumber);
				}
		
		//获取工厂自己已经中标的订单
		public ArrayList<Order> getZhongBiaoList(String orderState, User user) throws Exception {
			
			return orderDao.getZhongBiaoList(orderState,user);
		}
		public void modifyOrderState1(ArrayList<String> list) throws Exception {
			// TODO Auto-generated method stub
			orderDao.modifyOrderState1(list);
		}
		public void modifyOrderState2(ArrayList<String> list) throws Exception {
			// TODO Auto-generated method stub
			orderDao.modifyOrderState2(list);
		}
		public void modifyOrderState3(ArrayList<String> list) throws Exception {
			// TODO Auto-generated method stub
			orderDao.modifyOrderState3(list);
		}
		public void modifyOrderState4(ArrayList<String> list) throws Exception {
			orderDao.modifyOrderState4(list);
			
		}
}
