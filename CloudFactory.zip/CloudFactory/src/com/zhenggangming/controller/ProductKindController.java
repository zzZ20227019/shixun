package com.zhenggangming.controller;

import java.util.ArrayList;

import com.zhenggangming.Dao.ProductKindDao;
import com.zhenggangming.Dao.UserDao;
import com.zhenggangming.model.ProductKind;
import com.zhenggangming.model.User;

public class ProductKindController {
	private static ProductKindDao productKindDao = new ProductKindDao();
	private static ProductKindController productKindController = new ProductKindController();
	public static ProductKindController getInstance() {
		return productKindController;
	}
	//注册新的产品类别
	public boolean register(ProductKind productKind) throws Exception {
		String id = productKindDao.getMaxId();
		productKind.setId(id);
		productKindDao.saveProductKind(productKind);
		return true;
	}
	//删除产品类别
	public static void deleteProductKind(ArrayList<String> list) throws Exception {
		productKindDao.deleteProductKind(list);	
    }
	//修改产品类别
	public void modifyProductKind(ProductKind pk) throws Exception {
		productKindDao.modifyProductKind(pk);	
	}
	//获取全部产品类别列表  或   根据姓名获取产品类别列表
	public ArrayList<ProductKind> getList(String name) throws Exception {
		if(name == null) {
			return productKindDao.findProductKindList();
		}else {
			for(ProductKind pk : productKindDao.findProductKindList()) {
				if(pk.getName().equals(name)) {
					ArrayList<ProductKind> list = new ArrayList<>();
					list.add(pk);
					return list;
				}
			}
		}
		return null;
	}
	//根据id获取产品类别
		public ProductKind searchById(String id) throws Exception {
			return productKindDao.searchById(id);
		}
}
