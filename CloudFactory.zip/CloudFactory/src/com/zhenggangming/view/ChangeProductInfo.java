package com.zhenggangming.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;

import com.zhenggangming.controller.ProductController;
import com.zhenggangming.controller.ProductKindController;
import com.zhenggangming.model.Product;
import com.zhenggangming.model.ProductKind;
import com.zhenggangming.utils.ProductTable;
import com.zhenggangming.utils.UserTable;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
public class ChangeProductInfo extends JFrame {

	private JPanel contentPane;
	private JTextField serialNumber;
	private JTextField name;
	private JTextField standard;
	private JTextField description;
	private com.zhenggangming.model.Product product;
	private ProductController productController = ProductController.getInstance();


	/**
	 * Create the frame.
	 * @throws Exception 
	 */
	public ChangeProductInfo(String id , JTable table) throws Exception {
		product = productController.searchById(id);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 496);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("产品编号：");
		lblNewLabel.setBounds(49, 38, 68, 15);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("产品名称：");
		lblNewLabel_1.setBounds(49, 90, 68, 15);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("产品类别：");
		lblNewLabel_2.setBounds(49, 135, 68, 15);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("产品规格：");
		lblNewLabel_3.setBounds(49, 189, 68, 15);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("产品描述：");
		lblNewLabel_4.setBounds(49, 250, 68, 15);
		contentPane.add(lblNewLabel_4);
		
		serialNumber = new JTextField();
		serialNumber.setText(product.getSerialNumber());
		serialNumber.setEditable(false);
		serialNumber.setBounds(127, 35, 223, 21);
		contentPane.add(serialNumber);
		serialNumber.setColumns(10);
		
		name = new JTextField();
		name.setText(product.getName());
		name.setBounds(127, 87, 223, 21);
		contentPane.add(name);
		name.setColumns(10);
		
		standard = new JTextField();
		standard.setText(product.getStandard());
		standard.setBounds(127, 186, 223, 21);
		contentPane.add(standard);
		standard.setColumns(10);
		
		description = new JTextField();
		description.setText(product.getDescription());
		description.setBounds(127, 247, 223, 148);
		contentPane.add(description);
		description.setColumns(10);
		
		ArrayList<ProductKind> list = ProductKindController.getInstance().getList(null);
		int number = list.size();
		String[] str = new String[number];
		String str1 = product.getKind();
		int flag=0;
		for(int i=0;i<list.size();i++) {
			str[i] = list.get(i).getName();
		}
		for(int i=0;i<list.size();i++) {
			if(str[i].equals(str1)) {
				flag=i;
			}
		}
		JComboBox comboBox = new JComboBox(str);
	    comboBox.setSelectedItem(str[flag]);
		comboBox.setBounds(127, 131, 223, 23);
		contentPane.add(comboBox);
		
		JButton submit = new JButton("确定");
		submit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				product.setName(name.getText());
				product.setKind((String)comboBox.getSelectedItem());
				product.setStandard(standard.getText());
				product.setDescription(description.getText());
				try {
					productController.modifyProduct(product);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				JOptionPane.showMessageDialog(contentPane, "修改成功", "标题", JOptionPane.WARNING_MESSAGE);
				ProductTable ut = null;
				try {
					ut = new ProductTable(null);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setModel(ut);
				table.updateUI();
			}
		});
		submit.setBounds(202, 426, 97, 23);
		contentPane.add(submit);
		
		JButton reset = new JButton("返回");
		reset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		reset.setBounds(313, 426, 97, 23);
		contentPane.add(reset);
	}
}
