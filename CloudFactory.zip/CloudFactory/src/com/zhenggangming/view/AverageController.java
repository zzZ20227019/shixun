package com.zhenggangming.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.zhenggangming.controller.EquipmentController;
import com.zhenggangming.model.Equipment;
import com.zhenggangming.model.Product;
import com.zhenggangming.model.User;
import com.zhenggangming.utils.EquipmentTable1;
import com.zhenggangming.utils.EquipmentTable2;
import com.zhenggangming.utils.EquipmentTable3;

import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class AverageController extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField input;

	/**
	 * Create the frame.
	 * @throws Exception 
	 */
	public AverageController(User user) throws Exception {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 677, 473);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("新建");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					new AddEquipment2(table,user).setVisible(true);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				};
			}
		});
		btnNewButton.setBounds(40, 62, 97, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("租用设备");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					new Rent(user,table).setVisible(true);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_1.setBounds(158, 62, 97, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("删除");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ArrayList<String> list = new ArrayList<>();
				int num = table.getRowCount();
				for(int i=0;i<num;i++) {
					if((boolean)table.getValueAt(i, 0)==true) {
						String id = (String) table.getValueAt(i, 1);
						list.add(id);
					}
				}
				try {
					EquipmentController.getInstance().deleteEquipment2(list,user.getFactoryName());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				EquipmentTable2 pkt = null;
				try {
					pkt = new EquipmentTable2(user.getFactoryName());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setModel(pkt);
				table.updateUI();
			}
		});
		btnNewButton_2.setBounds(394, 62, 97, 23);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("设备状态");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ArrayList<String> list = new ArrayList<>();
				int num = table.getRowCount();
				for(int i=0;i<num;i++) {
					if((boolean)table.getValueAt(i, 0)==true) {
						String id = (String) table.getValueAt(i, 1);
						list.add(id);
					}
				}
				try {
					EquipmentController.getInstance().modifyEquipmentState(list);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				EquipmentTable2 ut = null;
				try {
					ut = new EquipmentTable2(user.getFactoryName());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			    table.setModel(ut);
			    table.updateUI();
			}
		});
		btnNewButton_3.setBounds(517, 62, 97, 23);
		contentPane.add(btnNewButton_3);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(40, 95, 600, 286);
		contentPane.add(scrollPane);
		
		EquipmentTable2 pkt = new EquipmentTable2(user.getFactoryName());
		table = new JTable(pkt);
		scrollPane.setViewportView(table);
		
		input = new JTextField();
		input.setBounds(40, 20, 215, 21);
		contentPane.add(input);
		input.setColumns(10);
		
		JButton btnNewButton_4 = new JButton("查找");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = input.getText();
				EquipmentTable1 pkt = null;
				try {
					pkt = new EquipmentTable1(name);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setModel(pkt);
				table.updateUI();
			}
		});
		btnNewButton_4.setBounds(295, 19, 97, 23);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("重置");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				input.setText("");
				EquipmentTable2 pkt = null;
				try {
					pkt = new EquipmentTable2(user.getFactoryName());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setModel(pkt);
				table.updateUI();
			}
		});
		btnNewButton_5.setBounds(409, 19, 97, 23);
		contentPane.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("修改");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int num = table.getRowCount();
				for(int i=0;i<num;i++) {
					if((boolean)table.getValueAt(i, 0)==true) {
						String id = (String) table.getValueAt(i, 1);
				try {
					new ChangeEquipmentInfo(id, table).setVisible(true);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
					}
				}
			}
		});
		btnNewButton_6.setBounds(517, 19, 97, 23);
		contentPane.add(btnNewButton_6);
		
		JButton Hour = new JButton("添加产能");
		Hour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = null;
				int num = table.getRowCount();
				Equipment ep = null;
				for(int i=0;i<num;i++) {
					if((boolean)table.getValueAt(i, 0)==true) {
						id = (String) table.getValueAt(i, 1);
					}
				}
			    try {
				     ep = EquipmentController.getInstance().searchById(id);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			    try {
					new AddCapacity(table,ep).setVisible(true);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			    
			}
		});
		Hour.setBounds(282, 62, 97, 23);
		contentPane.add(Hour);
		
		JButton btnNewButton_7 = new JButton("订单接单");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					new AddOrder(table,user).setVisible(true);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_7.setBounds(40, 403, 97, 23);
		contentPane.add(btnNewButton_7);
		
		JButton btnNewButton_8 = new JButton("订单排产");
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					new ArrangeOrder(user).setVisible(true);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_8.setBounds(174, 403, 97, 23);
		contentPane.add(btnNewButton_8);
		
		JButton btnNewButton_9 = new JButton("刷新");
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EquipmentTable2 ut = null;
				try {
					ut = new EquipmentTable2(user.getFactoryName());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			    table.setModel(ut);
			    table.updateUI();
			}
		});
		btnNewButton_9.setBounds(360, 403, 97, 23);
		contentPane.add(btnNewButton_9);
	}
}
