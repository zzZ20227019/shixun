package com.zhenggangming.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import com.zhenggangming.controller.EquipmentController;
import com.zhenggangming.controller.OrderController;
import com.zhenggangming.model.Equipment;
import com.zhenggangming.model.Order;
import com.zhenggangming.model.Product;
import com.zhenggangming.model.User;
import com.zhenggangming.utils.OrderTable4;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class GiveOrderCapacity extends JFrame {

	private JPanel contentPane;
	private JTextField start;
	private JTextField end;
	private Order order;
    private JComboBox comboBox;
	/**
	 * Create the frame.
	 * @throws Exception 
	 */
	public GiveOrderCapacity(User user,String orderNumber,JTable table1) throws Exception {
		order = OrderController.getInstance().searchByOrderNumber(orderNumber);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 669, 288);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("设备名称：");
		lblNewLabel.setBounds(26, 74, 80, 22);
		contentPane.add(lblNewLabel);
		
		ArrayList<Equipment> list = EquipmentController.getFactoryEquipmentList(user.getFactoryName());
		ArrayList<Equipment> list1 = new ArrayList<>();
		for(Equipment ep : list) {
			for(Product p : ep.getCapacity().keySet()) {
				if(p.getName().equals(order.getName())) {
					list1.add(ep);
				}
			}
		}
		String[] str = new String[list1.size()];
		for(int i=0;i<list1.size();i++) {
			str[i] = list1.get(i).getName();
		}
		comboBox = new JComboBox(str);
		comboBox.setBounds(116, 74, 196, 23);
		contentPane.add(comboBox);
		
		JLabel lblNewLabel_1 = new JLabel("开始时间：");
		lblNewLabel_1.setBounds(26, 132, 68, 15);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("结束时间：");
		lblNewLabel_2.setBounds(26, 188, 74, 15);
		contentPane.add(lblNewLabel_2);
		
		start = new JTextField();
		start.setBounds(114, 135, 205, 21);
		contentPane.add(start);
		start.setColumns(10);
		
		end = new JTextField();
		end.setBounds(117, 192, 201, 21);
		contentPane.add(end);
		end.setColumns(10);
		
		JButton btnNewButton = new JButton("添加");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(contentPane, "添加成功", "标题", JOptionPane.WARNING_MESSAGE);
				ArrayList<String> list = new ArrayList<>();
				list.add(orderNumber);
				try {
					OrderController.getInstance().modifyOrderState1(list);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				OrderTable4 ot = null;
				try {
					ot = new OrderTable4("已被接单",user);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table1.setModel(ot);
				table1.updateUI();
			}
		});
		btnNewButton.setBounds(425, 109, 97, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("返回");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnNewButton_1.setBounds(428, 173, 97, 23);
		contentPane.add(btnNewButton_1);
	}
}
