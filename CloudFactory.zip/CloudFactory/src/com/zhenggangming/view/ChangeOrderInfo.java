package com.zhenggangming.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import com.zhenggangming.Dao.OrderDao;
import com.zhenggangming.controller.EquipmentKindController;
import com.zhenggangming.controller.OrderController;
import com.zhenggangming.controller.ProductController;
import com.zhenggangming.model.EquipmentKind;
import com.zhenggangming.model.Order;
import com.zhenggangming.model.Product;
import com.zhenggangming.utils.EquipmentTable1;
import com.zhenggangming.utils.OrderTable1;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class ChangeOrderInfo extends JFrame {

	private JPanel contentPane;
	private JTextField serialNumber;
	private JTextField number;
	private JTextField JiaoFuDate;
	private JTextField TouBiaoEndDate;
	private JTextField reveiver;
	private JTextField address;
	private JTextField phone;
	private JComboBox comboBox;
	private Order order;
	private OrderDao orderDao = new OrderDao();
	
	/**
	 * Create the frame.
	 * @throws Exception 
	 */
	public ChangeOrderInfo(String id,JTable table) throws Exception {
		order = OrderController.getInstance().searchById(id);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 493);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		ArrayList<Product> list = ProductController.getInstance().getList(null);
		int number1 = list.size();
		String[] str = new String[number1];
		for(int i=0;i<list.size();i++) {
			str[i] = list.get(i).getName();
		}
	    comboBox = new JComboBox(str);
	    comboBox.setSelectedItem(order.getName());
		comboBox.setBounds(93, 59, 207, 23);
		contentPane.add(comboBox);
		
		JLabel lblNewLabel = new JLabel("产品名称：");
		lblNewLabel.setBounds(22, 63, 72, 15);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("产品编号：");
		lblNewLabel_1.setBounds(22, 114, 73, 15);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("采购数量：");
		lblNewLabel_2.setBounds(22, 161, 75, 15);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("交付日期：");
		lblNewLabel_3.setBounds(22, 209, 72, 15);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("投标截止日期:");
		lblNewLabel_4.setBounds(20, 253, 95, 18);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("收货人：");
		lblNewLabel_5.setBounds(20, 298, 58, 15);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("收货地址：");
		lblNewLabel_6.setBounds(17, 345, 77, 15);
		contentPane.add(lblNewLabel_6);
		
		JLabel label = new JLabel("收货人联系方式：");
		label.setBounds(20, 385, 109, 15);
		contentPane.add(label);
		
		serialNumber = new JTextField();
		serialNumber.setText(orderDao.getOrderNumber());
		serialNumber.setEditable(false);
		serialNumber.setBounds(95, 112, 237, 21);
		contentPane.add(serialNumber);
		serialNumber.setColumns(10);
		
		number = new JTextField();
		number.setText(""+order.getNumber());
		number.setBounds(94, 161, 239, 21);
		contentPane.add(number);
		number.setColumns(10);
		
		JiaoFuDate = new JTextField();
		JiaoFuDate.setText(order.getJiaoFuDate());
		JiaoFuDate.setBounds(93, 209, 240, 21);
		contentPane.add(JiaoFuDate);
		JiaoFuDate.setColumns(10);
		
		TouBiaoEndDate = new JTextField();
		TouBiaoEndDate.setText(order.getTouBiaoEndDate());
		TouBiaoEndDate.setBounds(102, 252, 232, 21);
		contentPane.add(TouBiaoEndDate);
		TouBiaoEndDate.setColumns(10);
		
		reveiver = new JTextField();
		reveiver.setText(order.getReceiver());
		reveiver.setBounds(94, 297, 240, 21);
		contentPane.add(reveiver);
		reveiver.setColumns(10);
		
		address = new JTextField();
		address.setText(order.getAddress());
		address.setBounds(93, 343, 246, 21);
		contentPane.add(address);
		address.setColumns(10);
		
		phone = new JTextField();
		phone.setText(""+order.getPhone());
		phone.setBounds(111, 381, 236, 21);
		contentPane.add(phone);
		phone.setColumns(10);
		
		JButton btnNewButton = new JButton("修改");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				order.setSerialNumber(serialNumber.getText());
				order.setNumber(Integer.parseInt(number.getText()));
				order.setJiaoFuDate(JiaoFuDate.getText());
				order.setTouBiaoEndDate(TouBiaoEndDate.getText());
				order.setReceiver(reveiver.getText());
				order.setAddress(address.getText());
				order.setPhone(Integer.parseInt(phone.getText()));
				try {
					OrderController.getInstance().modifyOrder(order);;
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				JOptionPane.showMessageDialog(contentPane, "订单修改成功", "标题", JOptionPane.WARNING_MESSAGE);
				OrderTable1 pkt = null;
				try {
					pkt = new OrderTable1(null);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setModel(pkt);
				table.updateUI();
			}
		});
		btnNewButton.setBounds(185, 430, 97, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("返回");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnNewButton_1.setBounds(310, 432, 97, 23);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_7 = new JLabel("新增订单");
		lblNewLabel_7.setFont(new Font("微软雅黑", Font.PLAIN, 30));
		lblNewLabel_7.setBounds(136, 8, 187, 42);
		contentPane.add(lblNewLabel_7);
	}

}
