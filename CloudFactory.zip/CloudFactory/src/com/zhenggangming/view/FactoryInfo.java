package com.zhenggangming.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.zhenggangming.controller.UserController;
import com.zhenggangming.utils.FactoryTable;
import com.zhenggangming.utils.UserTable;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FactoryInfo extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField input;

	/**
	 * Create the frame.
	 * @throws Exception 
	 */
	public FactoryInfo() throws Exception {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 724, 479);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton search = new JButton("工厂信息查询");
		search.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = input.getText();
				FactoryTable ft = null;
				try {
					ft = new FactoryTable(name);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setModel(ft);
				table.updateUI();
			}
		});
		search.setBounds(353, 20, 118, 23);
		contentPane.add(search);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(54, 98, 587, 321);
		contentPane.add(scrollPane);
		
		FactoryTable ft = new FactoryTable(null);
		table = new JTable(ft);
		scrollPane.setViewportView(table);
		
		input = new JTextField();
		input.setBounds(54, 21, 218, 21);
		contentPane.add(input);
		input.setColumns(10);
		
		JButton turn = new JButton("切换");
		turn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int num = table.getRowCount();
				for(int i=0;i<num;i++) {
					if((boolean)table.getValueAt(i, 0)==true) {
						String id = (String) table.getValueAt(i, 1);
						try {
							UserController.getInstance().setFactoryState(id);
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}
				FactoryTable ft = null;
				try {
					ft = new FactoryTable(null);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setModel(ft);
				table.updateUI();
			}
		});
		turn.setBounds(54, 66, 97, 23);
		contentPane.add(turn);
		
		JButton reset = new JButton("重置");
		reset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				input.setText("");
				FactoryTable ft = null;
				try {
					ft = new FactoryTable(null);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setModel(ft);
				table.updateUI();
			}
		});
		reset.setBounds(486, 20, 97, 23);
		contentPane.add(reset);
	}
}
