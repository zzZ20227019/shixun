package com.zhenggangming.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.zhenggangming.controller.EquipmentController;
import com.zhenggangming.model.User;
import com.zhenggangming.utils.EquipmentTable2;
import com.zhenggangming.utils.EquipmentTable3;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class Rent extends JFrame {

	private JPanel contentPane;
	private JTable table;


	/**
	 * Create the frame.
	 * @throws Exception 
	 */
	public Rent(User user,JTable table1) throws Exception {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 665, 395);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 56, 631, 292);
		contentPane.add(scrollPane);
		
		EquipmentTable3 et = null;
		et = new EquipmentTable3();
		table = new JTable(et);
		scrollPane.setViewportView(table);
		
		JButton rent = new JButton("租用");
		rent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ArrayList<String> list = new ArrayList<>();
				int num = table.getRowCount();
				for(int i=0;i<num;i++) {
					if((boolean)table.getValueAt(i, 0)==true) {
						String id = (String) table.getValueAt(i, 1);
						list.add(id);
					}
				}
				try {
					EquipmentController.getInstance().rentEquipment(list,user.getFactoryName());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				EquipmentTable3 pkt = null;
				EquipmentTable2 et = null;
				try {
					pkt = new EquipmentTable3();
					et = new EquipmentTable2(user.getFactoryName());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setModel(pkt);
				table.updateUI();
				table1.setModel(et);
				table1.updateUI();
			}
		});
		rent.setBounds(73, 23, 97, 23);
		contentPane.add(rent);
		
		JButton reset = new JButton("返回");
		reset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		reset.setBounds(404, 23, 97, 23);
		contentPane.add(reset);
	}
}
