package com.zhenggangming.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.zhenggangming.controller.OrderController;
import com.zhenggangming.model.Order;
import com.zhenggangming.model.User;
import com.zhenggangming.utils.OrderTable4;

import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JTable;

public class ArrangeOrder extends JFrame {

	private JPanel contentPane;
	private JTable table;


	/**
	 * Create the frame.
	 * @param user 
	 * @throws Exception 
	 */
	public ArrangeOrder(User user) throws Exception {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 700, 435);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(22, 66, 654, 287);
		contentPane.add(scrollPane);
		
		OrderTable4 ot = null;
		ot = new OrderTable4("已发布",user);
		table = new JTable(ot);
		scrollPane.setViewportView(table);
		
		JButton btnNewButton = new JButton("排产");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int num = table.getRowCount();
				for(int i=0;i<num;i++) {
					if((boolean)table.getValueAt(i, 0)==true) {
						String orderNumber = (String) table.getValueAt(i, 2);
						try {
							new GiveOrderCapacity(user, orderNumber,table).setVisible(true);
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}
			}
		});
		btnNewButton.setBounds(292, 33, 97, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("返回");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnNewButton_1.setBounds(552, 33, 97, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("发货");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int num = table.getRowCount();
				for(int i=0;i<num;i++) {
					if((boolean)table.getValueAt(i, 0)==true) {
						String orderNumber = (String) table.getValueAt(i, 2);
						ArrayList<String> list = new ArrayList<>();
						list.add(orderNumber);
					    try {
							OrderController.getInstance().modifyOrderState2(list);
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}
				OrderTable4 ot = null;
				try {
					ot = new OrderTable4("已发布",user);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setModel(ot);
				table.updateUI();
			}
		});
		btnNewButton_2.setBounds(424, 33, 97, 23);
		contentPane.add(btnNewButton_2);
	}

}
