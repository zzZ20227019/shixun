package com.zhenggangming.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.zhenggangming.controller.ProductController;
import com.zhenggangming.controller.ProductKindController;
import com.zhenggangming.utils.ProductKindTable;
import com.zhenggangming.utils.ProductTable;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class Product extends JFrame {

	private JPanel contentPane;
	private JTextField input;
	private JTable table;

	/**
	 * Create the frame.
	 * @throws Exception 
	 */
	public Product() throws Exception {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 694, 465);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		input = new JTextField();
		input.setBounds(54, 22, 213, 21);
		contentPane.add(input);
		input.setColumns(10);
		
		JButton btnNewButton = new JButton("产品查询");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = input.getText();
				ProductTable pkt = null;
				try {
					pkt = new ProductTable(name);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setModel(pkt);
				table.updateUI();
			}
		});
		btnNewButton.setBounds(298, 21, 97, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("重置");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				input.setText("");
				ProductTable pkt = null;
				try {
					pkt = new ProductTable(null);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setModel(pkt);
				table.updateUI();
			}
		});
		btnNewButton_1.setBounds(454, 21, 97, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("新建");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					new AddProduct(table).setVisible(true);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_2.setBounds(54, 71, 97, 23);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("删除");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ArrayList<String> list = new ArrayList<>();
				int num = table.getRowCount();
				for(int i=0;i<num;i++) {
					if((boolean)table.getValueAt(i, 0)==true) {
						String id = (String) table.getValueAt(i, 1);
						list.add(id);
					}
				}
				try {
					ProductController.deleteProduct(list);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				JOptionPane.showMessageDialog(contentPane, "成功", "标题", JOptionPane.WARNING_MESSAGE);
			    ProductTable ut = null;
				try {
					ut = new ProductTable(null);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			    table.setModel(ut);
			    table.updateUI();
			}
		});
		btnNewButton_3.setBounds(187, 71, 97, 23);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("修改");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int num = table.getRowCount();
				for(int i=0;i<num;i++) {
					if((boolean)table.getValueAt(i, 0)==true) {
						String id = (String) table.getValueAt(i, 1);
				try {
					new ChangeProductInfo(id, table).setVisible(true);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
	}
		});
		btnNewButton_4.setBounds(514, 71, 97, 23);
		contentPane.add(btnNewButton_4);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(64, 113, 547, 267);
		contentPane.add(scrollPane);
		
		ProductTable pkt = new ProductTable(null);
		table = new JTable(pkt);
		scrollPane.setViewportView(table);
		
		JButton reset = new JButton("返回");
		reset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		reset.setBounds(514, 395, 97, 23);
		contentPane.add(reset);
	}
}
