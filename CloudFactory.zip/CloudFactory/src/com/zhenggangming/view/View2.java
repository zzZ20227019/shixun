package com.zhenggangming.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.zhenggangming.controller.UserController;
import com.zhenggangming.model.User;
import com.zhenggangming.utils.UserDataValidate;
import com.zhenggangming.utils.UserTable;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;

public class View2 extends JFrame {

	private JPanel contentPane;
	private JTextField account;
	private JTextField password;
	private JTextField name;
	private JTextField phone;
	private JTextField factoryName;
	private JTextField introduction;
	private UserController userController = UserController.getInstance();

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 * @param table 
	 */
	public View2(JTable table) {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("登陆账号:");
		lblNewLabel.setBounds(36, 10, 58, 15);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("登录密码:");
		lblNewLabel_1.setBounds(36, 35, 58, 15);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("真实姓名:");
		lblNewLabel_2.setBounds(36, 60, 58, 15);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("联系方式:");
		lblNewLabel_3.setBounds(36, 85, 58, 15);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("注册类别:");
		lblNewLabel_4.setBounds(36, 110, 58, 15);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("工厂名称:");
		lblNewLabel_5.setBounds(36, 138, 58, 15);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("工厂简介：");
		lblNewLabel_6.setBounds(36, 163, 60, 15);
		contentPane.add(lblNewLabel_6);
		
		account = new JTextField();
		account.setBounds(104, 7, 171, 21);
		contentPane.add(account);
		account.setColumns(10);
		
		password = new JTextField();
		password.setBounds(104, 32, 171, 21);
		contentPane.add(password);
		password.setColumns(10);
		
		name = new JTextField();
		name.setBounds(104, 57, 171, 21);
		contentPane.add(name);
		name.setColumns(10);
		
		phone = new JTextField();
		phone.setBounds(104, 82, 171, 21);
		contentPane.add(phone);
		phone.setColumns(10);
		
		factoryName = new JTextField();
		factoryName.setBounds(104, 135, 171, 21);
		contentPane.add(factoryName);
		factoryName.setColumns(10);
		
		introduction = new JTextField();
		introduction.setBounds(106, 160, 169, 21);
		contentPane.add(introduction);
		introduction.setColumns(10);
		
		JRadioButton cloudFactory = new JRadioButton("云工厂");
		cloudFactory.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//云工厂默认被选中
				cloudFactory.setSelected(true);
			}
		});
		cloudFactory.setBounds(101, 106, 127, 23);
		contentPane.add(cloudFactory);
		
		JRadioButton seller = new JRadioButton("经销商");
		seller.setBounds(230, 106, 127, 23);
		contentPane.add(seller);
		ButtonGroup group = new ButtonGroup();
		group.add(cloudFactory);
		group.add(seller);
		
		JButton registerButton = new JButton("提交");
		registerButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//获取用户信息，并封装到User实体对象中
				User user = new User();
				user.setAccount(account.getText());
				user.setPassword(password.getText());
				user.setPhone(phone.getText());
				user.setState("关停");
				user.setUserName(name.getText());
				if(cloudFactory.isSelected()){
					user.setPower(cloudFactory.getText());
				}else if(seller.isSelected()) {
					user.setPower(seller.getText());
				}
				user.setIntroduction(introduction.getText());
				user.setFactoryName(factoryName.getText());
//				try {
//					userController.register(user);
//				} catch (Exception e1) {
//					// TODO Auto-generated catch block
//					e1.printStackTrace();
//				}
//				JOptionPane.showMessageDialog(contentPane, "注册成功", "标题", JOptionPane.WARNING_MESSAGE);
				//验证信息
				String[] message = new String[3];
				try {
					message[0] = UserDataValidate.UserDateValidate1(user);
					message[1] = UserDataValidate.UserDateValidate2(user);
					message[2] = UserDataValidate.UserDateValidate3(user);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if(message[0].equals("") && message[1].equals("") && message[2].equals("") ) {
					try {
						userController.register(user);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					JOptionPane.showMessageDialog(contentPane, "注册成功", "标题", JOptionPane.WARNING_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(contentPane, message[0]+"\n"+message[1]+"\n"+message[2], "标题", JOptionPane.WARNING_MESSAGE);
				}
				if(table != null) {
					UserTable ut = null;
					try {
						ut = new UserTable(null);
					} catch (Exception e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					table.setModel(ut);
					table.updateUI();
				}
				
			}
		});
		registerButton.setBounds(46, 197, 97, 23);
		contentPane.add(registerButton);
		
		JButton close = new JButton("返回");
		close.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//关闭窗口
				
				dispose();
			}
		});
		close.setBounds(215, 197, 97, 23);
		contentPane.add(close);
	}
}
