package com.zhenggangming.view;
import com.zhenggangming.controller.ProductKindController;
import com.zhenggangming.model.ProductKind;
import com.zhenggangming.utils.ProductKindTable;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
public class ChangeProductKind extends JFrame {

	private JPanel contentPane;
	private JTextField kind;
    private ProductKindController  productKindController = ProductKindController.getInstance();
    private ProductKind pk;
	/**
	 * Create the frame.
	 * @throws Exception 
	 */
	public ChangeProductKind(String id,JTable table) throws Exception {
		pk = productKindController.searchById(id);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("类别名称:");
		lblNewLabel.setFont(new Font("微软雅黑", Font.PLAIN, 20));
		lblNewLabel.setBounds(26, 105, 101, 30);
		contentPane.add(lblNewLabel);
		
		kind = new JTextField();
		kind.setText(pk.getName());
		kind.setBounds(140, 109, 231, 27);
		contentPane.add(kind);
		kind.setColumns(10);
		
		JButton btnNewButton = new JButton("确定");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pk.setName(kind.getText());
				try {
					productKindController.modifyProductKind(pk);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				JOptionPane.showMessageDialog(contentPane, "修改成功", "标题", JOptionPane.WARNING_MESSAGE);
				ProductKindTable pkt = null;
				try {
					pkt = new ProductKindTable(null);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setModel(pkt);
				table.updateUI();
				
			}
		});
		btnNewButton.setBounds(26, 198, 97, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("返回");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnNewButton_1.setBounds(274, 198, 97, 23);
		contentPane.add(btnNewButton_1);
	}
}
