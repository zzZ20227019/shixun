package com.zhenggangming.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.zhenggangming.controller.UserController;
import com.zhenggangming.model.User;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;

public class View1 extends JFrame {

	private JPanel contentPane;
	private JTextField userName;
	private JTextField password;
	private UserController userController = UserController.getInstance();
   
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					View1 frame = new View1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public View1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton registerButton = new JButton("注册");
		registerButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new View2(null).setVisible(true);
			}
		});
		registerButton.setBounds(113, 211, 97, 23);
		contentPane.add(registerButton);
		
		JButton login = new JButton("登录");
		login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String loginName = userName.getText();
				String loginPassWord = password.getText();
				User user = null;
				try {
					user = userController.login(loginName, loginPassWord);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
                if(user == null) {
                	JOptionPane.showMessageDialog(contentPane, "不存在该用户，请重新输入", "标题", JOptionPane.WARNING_MESSAGE);
                }else if(user.getPower()==null) {
                	new SuperController().setVisible(true);
                }else if(user.getPower().equals("云工厂")){
                	try {
                		if(user.getState().equals("关停")) {
                			JOptionPane.showMessageDialog(contentPane, "该用户已关停，请联系超级管理员", "标题", JOptionPane.WARNING_MESSAGE);
                		}else {
                			new AverageController(user).setVisible(true);	
                		}
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
                }else if(user.getPower().equals("经销商")){
                	try {
                		if(user.getState().equals("关停")) {
                			JOptionPane.showMessageDialog(contentPane, "该用户已关停，请联系超级管理员", "标题", JOptionPane.WARNING_MESSAGE);
                		}else {
                			new Dealer().setVisible(true);	
                		}
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
                }
			}
		});
		login.setBounds(246, 211, 97, 23);
		contentPane.add(login);
		
		JLabel lblNewLabel = new JLabel("云平台制造");
		lblNewLabel.setFont(new Font("微软雅黑", Font.PLAIN, 20));
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setBounds(165, 42, 100, 40);
		contentPane.add(lblNewLabel);
	
		userName = new JTextField();
		userName.setBounds(144, 80, 199, 21);
		contentPane.add(userName);
		userName.setColumns(10);
		
		password = new JTextField();
		password.setBounds(144, 120, 199, 21);
		contentPane.add(password);
		password.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("用户名");
		lblNewLabel_1.setFont(new Font("微软雅黑", Font.PLAIN, 17));
		lblNewLabel_1.setBounds(50, 80, 68, 18);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("密码");
		lblNewLabel_2.setFont(new Font("微软雅黑", Font.PLAIN, 17));
		lblNewLabel_2.setBounds(66, 120, 68, 18);
		contentPane.add(lblNewLabel_2);
		
//	    JLabel background=new JLabel(new ImageIcon("bg.jpg"));
//	    background.setBounds(100, 100, 400,300);
//	    contentPane.add(background);
	}
}
