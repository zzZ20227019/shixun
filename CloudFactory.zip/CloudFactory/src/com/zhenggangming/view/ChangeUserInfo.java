package com.zhenggangming.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import com.zhenggangming.controller.UserController;
import com.zhenggangming.model.User;
import com.zhenggangming.utils.UserDataValidate;
import com.zhenggangming.utils.UserTable;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JToggleButton;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ChangeUserInfo extends JFrame {

	private JPanel contentPane;
	private JTextField account;
	private JTextField password;
	private JTextField name;
	private JTextField phone;
	private User user;
	private UserController userController = UserController.getInstance();
	/**
	 * Create the frame.
	 * @param table 
	 * @throws Exception 
	 */
	public ChangeUserInfo(String id, JTable table) throws Exception {
		user = userController.searchById(id);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 546, 540);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel1 = new JLabel("密码：");
		lblNewLabel1.setBounds(59, 109, 58, 15);
		contentPane.add(lblNewLabel1);
		
		JLabel lblNewLabel2 = new JLabel("真实姓名：");
		lblNewLabel2.setBounds(59, 174, 70, 15);
		contentPane.add(lblNewLabel2);
		
		JLabel lblNewLabel3 = new JLabel("联系方式：");
		lblNewLabel3.setBounds(59, 233, 70, 15);
		contentPane.add(lblNewLabel3);
		
		JLabel lblNewLabel4 = new JLabel("用户信息：");
		lblNewLabel4.setBounds(59, 301, 70, 15);
		contentPane.add(lblNewLabel4);
		
		account = new JTextField();
		account.setText(user.getAccount());
		account.setBounds(127, 47, 280, 21);
		contentPane.add(account);
		account.setColumns(10);
		
		password = new JTextField();
		password.setText(user.getPassword());
		password.setEditable(false);
		password.setBounds(125, 106, 280, 21);
		contentPane.add(password);
		password.setColumns(10);
		
		name = new JTextField();
		name.setText(user.getUserName());
		name.setBounds(130, 169, 274, 21);
		contentPane.add(name);
		name.setColumns(10);
		
		phone = new JTextField();
		phone.setText(user.getPhone());
		phone.setBounds(130, 231, 283, 21);
		contentPane.add(phone);
		phone.setColumns(10);
		
		String str[]= {"云工厂","经销商"};
		JComboBox comboBox = new JComboBox(str);
		if(user.getPower().equals("云工厂")){
		      comboBox.setSelectedIndex(0);
		    }else if(user.getPower().equals("经销商")){
		      comboBox.setSelectedIndex(1);
		    }
		String str11[]= {"关停","开启"};
		JComboBox comboBox_1 = new JComboBox(str11);
		if(user.getState().equals("关停")){
		      comboBox_1.setSelectedIndex(0);
		    }else if(user.getState().equals("开启")){
		      comboBox_1.setSelectedIndex(1);
		    }
		comboBox_1.setBounds(138, 356, 269, 23);
		contentPane.add(comboBox_1);
//		if(user.getPower().equals("云工厂")) {
//			comboBox.setModel(new DefaultComboBoxModel(new String[] {"云工厂", "经销商"}));
//		}else if(user.getPower().equals("经销商")) {
//			comboBox.setModel(new DefaultComboBoxModel(new String[] {"经销商", "云工厂"}));
//		}
		String str1 = (String) comboBox.getSelectedItem();
		
		comboBox.setBounds(133, 297, 274, 21);
		contentPane.add(comboBox);
		
		JLabel lblNewLabel = new JLabel("账号：");
		lblNewLabel.setBounds(59, 50, 58, 15);
		contentPane.add(lblNewLabel);
		
		JButton Sure = new JButton("确定");
		Sure.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				user.setAccount(account.getText());
				user.setPassword(password.getText());
				user.setUserName(name.getText());
				user.setPhone(phone.getText());
				user.setPower((String) comboBox.getSelectedItem());
				user.setState((String)comboBox_1.getSelectedItem());

						try {
							userController.modify(user);
						} catch (Exception e2) {
							// TODO Auto-generated catch block
							e2.printStackTrace();
						}
//					} catch (Exception e1) {
//						e1.printStackTrace();
//					}
					JOptionPane.showMessageDialog(contentPane, "修改成功", "标题", JOptionPane.WARNING_MESSAGE);
//				}else {
//					JOptionPane.showMessageDialog(contentPane, message[0]+"\n"+message[1]+"\n"+message[2], "标题", JOptionPane.WARNING_MESSAGE);
//				}
				UserTable ut = null;
				try {
					ut = new UserTable(null);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setModel(ut);
				table.updateUI();
			    System.out.println(str1);
			}
		});
		Sure.setBounds(310, 442, 97, 23);
		contentPane.add(Sure);
		
		JButton goBack = new JButton("返回");
		goBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		goBack.setBounds(425, 442, 97, 23);
		contentPane.add(goBack);
		
		JLabel lblNewLabel_1 = new JLabel("登陆状态：");
		lblNewLabel_1.setBounds(59, 360, 70, 15);
		contentPane.add(lblNewLabel_1);
		
		
	}
}
