package com.zhenggangming.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.zhenggangming.model.User;
import com.zhenggangming.utils.OrderTable1;
import com.zhenggangming.utils.OrderTable3;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AddOrder extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Create the frame.
	 * @throws Exception 
	 */
	public AddOrder(JTable table1,User user) throws Exception {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 717, 377);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(43, 51, 617, 262);
		contentPane.add(scrollPane);
		
		OrderTable3 ot = new OrderTable3("发布");
		table = new JTable(ot);
		scrollPane.setViewportView(table);
		
		JButton btnNewButton = new JButton("竞标");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int num = table.getRowCount();
				for(int i=0;i<num;i++) {
					if((boolean)table.getValueAt(i, 0)==true) {
						String orderNumber = (String) table.getValueAt(i, 2);
				try {
					    /*new BidBook(user,orderNumber).setVisible(true);*/
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
					}
				}
			}
		});
		btnNewButton.setBounds(422, 18, 97, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("返回");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnNewButton_1.setBounds(552, 18, 97, 23);
		contentPane.add(btnNewButton_1);
	}

}
