package com.zhenggangming.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.zhenggangming.controller.EquipmentKindController;
import com.zhenggangming.model.EquipmentKind;
import com.zhenggangming.utils.EquipmentKindTable;
public class ChangeEquipmentKind extends JFrame {

	private JPanel contentPane;
	private JTextField kind;
	private EquipmentKindController equipmentKindController = EquipmentKindController.getInstance();
	private EquipmentKind ek;
	/**
	 * Create the frame.
	 * @throws Exception 
	 */
	public ChangeEquipmentKind(String id,JTable table) throws Exception {
		ek = equipmentKindController.searchById(id);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("类别名称:");
		lblNewLabel.setFont(new Font("微软雅黑", Font.PLAIN, 20));
		lblNewLabel.setBounds(26, 105, 101, 30);
		contentPane.add(lblNewLabel);
		
		kind = new JTextField();
		kind.setText(ek.getName());
		kind.setBounds(140, 109, 231, 27);
		contentPane.add(kind);
		kind.setColumns(10);
		
		JButton btnNewButton = new JButton("确定");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ek.setName(kind.getText());
				try {
					equipmentKindController.modifyEquipmentKind(ek);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				JOptionPane.showMessageDialog(contentPane, "修改成功", "标题", JOptionPane.WARNING_MESSAGE);
				EquipmentKindTable ekt = null;
				try {
					ekt = new EquipmentKindTable(null);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setModel(ekt);
				table.updateUI();
				
			}
		});
		btnNewButton.setBounds(26, 198, 97, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("返回");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnNewButton_1.setBounds(274, 198, 97, 23);
		contentPane.add(btnNewButton_1);
	}

}
