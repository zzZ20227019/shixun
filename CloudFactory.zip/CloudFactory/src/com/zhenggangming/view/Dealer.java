package com.zhenggangming.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.zhenggangming.controller.OrderController;
import com.zhenggangming.utils.OrderTable1;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class Dealer extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JButton btnNewButton_1;
	private JButton btnNewButton_2;
	private JButton btnNewButton_3;
	private JButton btnNewButton_4;
	private JButton btnNewButton_5;
	private JButton btnNewButton_6;

	/**
	 * Create the frame.
	 * @throws Exception 
	 */
	public Dealer() throws Exception {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 678, 457);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 70, 644, 280);
		contentPane.add(scrollPane);
		
		OrderTable1 ot = null;
		ot = new OrderTable1(null);
		table = new JTable(ot);
		scrollPane.setViewportView(table);
		
		JButton btnNewButton = new JButton("新建");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					new NewOrder(table).setVisible(true);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton.setBounds(10, 27, 97, 23);
		contentPane.add(btnNewButton);
		
		btnNewButton_1 = new JButton("删除订单");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ArrayList<String> list = new ArrayList<>();
				int num = table.getRowCount();
				for(int i=0;i<num;i++) {
					if((boolean)table.getValueAt(i, 0)==true) {
						String id = (String) table.getValueAt(i, 1);
						list.add(id);
					}
				}
				try {
					OrderController.getInstance().deleteOrder(list);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				OrderTable1 pkt = null;
				try {
					pkt = new OrderTable1(null);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setModel(pkt);
				table.updateUI();
			}
		});
		btnNewButton_1.setBounds(117, 27, 97, 23);
		contentPane.add(btnNewButton_1);
		
		btnNewButton_2 = new JButton("修改");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int num = table.getRowCount();
				for(int i=0;i<num;i++) {
					if((boolean)table.getValueAt(i, 0)==true) {
						String id = (String) table.getValueAt(i, 1);
				try {
					if(OrderController.getInstance().isChangeable(id)) {
						new ChangeEquipmentInfo(id, table).setVisible(true);	
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
			}
		});
		btnNewButton_2.setBounds(224, 27, 97, 23);
		contentPane.add(btnNewButton_2);
		
		btnNewButton_3 = new JButton("发布");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ArrayList<String> list = new ArrayList<>();
				int num = table.getRowCount();
				for(int i=0;i<num;i++) {
					if((boolean)table.getValueAt(i, 0)==true) {
						String orderNumber = (String) table.getValueAt(i, 2);
						list.add(orderNumber);
					}
				}
				try {
					OrderController.getInstance().modifyOrderState(list);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				OrderTable1 pkt = null;
				try {
					pkt = new OrderTable1(null);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setModel(pkt);
				table.updateUI();
			}
		});
		btnNewButton_3.setBounds(438, 27, 97, 23);
		contentPane.add(btnNewButton_3);
		
		btnNewButton_4 = new JButton("查看竞标工厂");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int num = table.getRowCount();
				for(int i=0;i<num;i++) {
					if((boolean)table.getValueAt(i, 0)==true) {
						String orderNumber = (String) table.getValueAt(i, 2);
						try {
							/*new BidFactories(orderNumber,table).setVisible(true);*/
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}
			}
		});
		btnNewButton_4.setBounds(541, 27, 113, 23);
		contentPane.add(btnNewButton_4);
		
		btnNewButton_5 = new JButton("收货");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int num = table.getRowCount();
				for(int i=0;i<num;i++) {
					if((boolean)table.getValueAt(i, 0)==true) {
						String orderNumber = (String) table.getValueAt(i, 2);
						ArrayList<String> list = new ArrayList<>();
						list.add(orderNumber);
					    try {
					    	if(OrderController.getInstance().IsFaHuo(orderNumber)) {
					    		OrderController.getInstance().modifyOrderState3(list);
					    	}
					    	else {
					    		JOptionPane.showMessageDialog(contentPane, "订单尚未发货", "标题", JOptionPane.WARNING_MESSAGE);
					    	}
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}
				OrderTable1 pkt = null;
				try {
					pkt = new OrderTable1(null);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setModel(pkt);
				table.updateUI();
				}
		});
		btnNewButton_5.setBounds(331, 27, 97, 23);
		contentPane.add(btnNewButton_5);
		
		btnNewButton_6 = new JButton("刷新");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OrderTable1 pkt = null;
				try {
					pkt = new OrderTable1(null);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setModel(pkt);
				table.updateUI();
			}
		});
		btnNewButton_6.setBounds(10, 375, 97, 23);
		contentPane.add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("完成订单");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int num = table.getRowCount();
				for(int i=0;i<num;i++) {
					if((boolean)table.getValueAt(i, 0)==true) {
						String orderNumber = (String) table.getValueAt(i, 2);
						ArrayList<String> list = new ArrayList<>();
						list.add(orderNumber);
					    try {
							OrderController.getInstance().modifyOrderState4(list);
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}
				OrderTable1 pkt = null;
				try {
					pkt = new OrderTable1(null);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setModel(pkt);
				table.updateUI();
			}
		});
		btnNewButton_7.setBounds(557, 375, 97, 23);
		contentPane.add(btnNewButton_7);
	}
}
