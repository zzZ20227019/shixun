package com.zhenggangming.view;
import com.zhenggangming.controller.ProductKindController;
import com.zhenggangming.model.ProductKind;
import com.zhenggangming.utils.ProductKindTable;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;

public class AddProductKind extends JFrame {

	private JPanel contentPane;
	private JTextField kind;
    private ProductKind pk = new ProductKind();
    private JButton btnNewButton;
    private JButton reset;
	
	/**
	 * Create the frame.
	 * @param table 
	 */
	public AddProductKind(JTable table) {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("产品类别：");
		lblNewLabel.setBounds(37, 103, 75, 15);
		contentPane.add(lblNewLabel);
		
		kind = new JTextField();
		kind.setBounds(127, 100, 161, 21);
		contentPane.add(kind);
		kind.setColumns(10);
		
		btnNewButton = new JButton("确定");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pk.setName(kind.getText());;
				try {
					ProductKindController.getInstance().register(pk);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				JOptionPane.showMessageDialog(contentPane, "添加成功", "标题", JOptionPane.WARNING_MESSAGE);
				ProductKindTable pkt = null;
				try {
					pkt = new ProductKindTable(null);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setModel(pkt);
				table.updateUI();
			}
		});
		btnNewButton.setBounds(37, 180, 97, 23);
		contentPane.add(btnNewButton);
		
		reset = new JButton("返回");
		reset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		reset.setBounds(260, 180, 97, 23);
		contentPane.add(reset);
	}

}
