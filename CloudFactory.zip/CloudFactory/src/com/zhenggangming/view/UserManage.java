package com.zhenggangming.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.zhenggangming.controller.UserController;
import com.zhenggangming.utils.DataFileName;
import com.zhenggangming.utils.UserTable;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;

public class UserManage extends JFrame {

	private JPanel contentPane;
	private JTextField input;
	private JButton delete;
	private JTable table;
	//private UserTable ut1 = new UserTable(DataFileName.USER.toString());

	/**
	 * Create the frame.
	 * @throws Exception 
	 */
	public UserManage() throws Exception {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 705, 371);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		input = new JTextField();
		input.setBounds(47, 30, 158, 21);
		contentPane.add(input);
		input.setColumns(10);
		
		JButton reset = new JButton("重置");
		reset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				input.setText("");
				UserTable ut = null;
				try {
					ut = new UserTable(null);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setModel(ut);
				table.updateUI();
			}
		});
		reset.setBounds(368, 29, 97, 23);
		contentPane.add(reset);
		
		JButton add = new JButton("新建");
		add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new View2(table).setVisible(true);
			}
		});
		add.setBounds(47, 80, 97, 23);
		contentPane.add(add);
		
		delete = new JButton("删除");
		delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ArrayList<String> list = new ArrayList<>();
				int num = table.getRowCount();
				for(int i=0;i<num;i++) {
					if((boolean)table.getValueAt(i, 0)==true) {
						String id = (String) table.getValueAt(i, 1);
						list.add(id);
					}
				}
				try {
					UserController.deleteUser(list);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				JOptionPane.showMessageDialog(contentPane, "成功", "标题", JOptionPane.WARNING_MESSAGE);
			    UserTable ut = null;
				try {
					ut = new UserTable(null);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			    table.setModel(ut);
			    table.updateUI();
			}
		});
		delete.setBounds(188, 80, 97, 23);
		contentPane.add(delete);
		
		JButton change = new JButton("修改");
		change.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int num = table.getRowCount();
				for(int i=0;i<num;i++) {
					if((boolean)table.getValueAt(i, 0)==true) {
						String id = (String) table.getValueAt(i, 1);
	                    try {
							new ChangeUserInfo(id,table).setVisible(true);
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}
			}
		});
		change.setBounds(502, 80, 97, 23);
		contentPane.add(change);
		
		JButton goBack = new JButton("返回");
		goBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		goBack.setBounds(584, 311, 97, 23);
		contentPane.add(goBack);
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(47, 113, 552, 188);
		contentPane.add(scrollPane);
		
		UserTable ut = new UserTable(null);
		table = new JTable(ut);
		scrollPane.setViewportView(table);
		
		JButton userSearch = new JButton("用户查询");
		userSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = input.getText();
				UserTable ut = null;
				try {
					ut = new UserTable(name);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setModel(ut);
				table.updateUI();
			}
		});
		userSearch.setBounds(234, 29, 97, 23);
		contentPane.add(userSearch);
	}
}
