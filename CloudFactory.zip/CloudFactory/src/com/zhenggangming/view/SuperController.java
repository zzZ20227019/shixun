package com.zhenggangming.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SuperController extends JFrame {

	private JPanel contentPane;

	/**
	 * Create the frame.
	 */
	public SuperController() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton userControl = new JButton("用户管理");
		userControl.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					new UserManage().setVisible(true);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		userControl.setBounds(131, 57, 134, 23);
		contentPane.add(userControl);
		
		JButton factoryInfo = new JButton("云工厂信息");
		factoryInfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					new FactoryInfo().setVisible(true);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		factoryInfo.setBounds(131, 106, 134, 23);
		contentPane.add(factoryInfo);
		
		JButton productKindControl = new JButton("产品类别管理");
		productKindControl.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					new ProductKind().setVisible(true);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		productKindControl.setBounds(131, 155, 134, 23);
		contentPane.add(productKindControl);
		
		JButton productInfoControl = new JButton("产品信息管理");
		productInfoControl.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					new Product().setVisible(true);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		productInfoControl.setBounds(131, 204, 134, 23);
		contentPane.add(productInfoControl);
		
		JButton equipmentKindControl = new JButton("设备类型管理");
		equipmentKindControl.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					new EquipmentKind().setVisible(true);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		equipmentKindControl.setBounds(131, 250, 134, 23);
		contentPane.add(equipmentKindControl);
		
		JButton equipmentControl = new JButton("设备管理");
		equipmentControl.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					new Equipment().setVisible(true);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		equipmentControl.setBounds(131, 294, 134, 23);
		contentPane.add(equipmentControl);
	}
}
