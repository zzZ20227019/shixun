package com.zhenggangming.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;

import com.zhenggangming.controller.EquipmentController;
import com.zhenggangming.controller.EquipmentKindController;
import com.zhenggangming.controller.ProductController;
import com.zhenggangming.model.Equipment;
import com.zhenggangming.model.EquipmentKind;
import com.zhenggangming.model.Product;
import com.zhenggangming.utils.EquipmentTable3;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;

public class AddCapacity extends JFrame {

	private JPanel contentPane;
	private JTextField serialNumber;
	private JTextField equipmentName;
	private JTextField hour;
	private HashMap<Product,Integer> map = null;
	JComboBox comboBox;
    /**
	 * Create the frame.
     * @throws Exception 
	 */
	public AddCapacity(JTable table,Equipment ep) throws Exception {
		map = ep.getCapacity();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 734, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("设备编号：");
		lblNewLabel.setBounds(38, 21, 68, 23);
		contentPane.add(lblNewLabel);
		
		serialNumber = new JTextField();
		serialNumber.setText(ep.getSerialNumber());
		serialNumber.setEditable(false);
		serialNumber.setBounds(116, 22, 197, 21);
		contentPane.add(serialNumber);
		serialNumber.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("设备名称：");
		lblNewLabel_1.setBounds(365, 23, 77, 19);
		contentPane.add(lblNewLabel_1);
		
		equipmentName = new JTextField();
		equipmentName.setText(ep.getName());
		equipmentName.setEditable(false);
		equipmentName.setBounds(436, 22, 218, 21);
		contentPane.add(equipmentName);
		equipmentName.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("产品名称：");
		lblNewLabel_2.setBounds(38, 109, 68, 15);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("产品产能：");
		lblNewLabel_3.setBounds(365, 109, 68, 15);
		contentPane.add(lblNewLabel_3);
		
		hour = new JTextField();
		hour.setBounds(436, 106, 218, 21);
		contentPane.add(hour);
		hour.setColumns(10);
		
		JButton submit = new JButton("确定");
		submit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Product p = null;
				try {
					p = ProductController.getInstance().searchByName((String)comboBox.getSelectedItem());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				map.put(p, Integer.parseInt(hour.getText()));
				ep.setCapacity(map);
				try {
					EquipmentController.addCapacity(ep);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				EquipmentTable3 et = null;
				try {
					et = new EquipmentTable3();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				JOptionPane.showMessageDialog(contentPane, "成功", "标题", JOptionPane.WARNING_MESSAGE);
				table.setModel(et);
				table.updateUI();
			//	map.put(key, value)
			}
		});
		submit.setBounds(208, 230, 97, 23);
		contentPane.add(submit);
		
		JButton btnNewButton_1 = new JButton("返回");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnNewButton_1.setBounds(413, 230, 97, 23);
		contentPane.add(btnNewButton_1);
		
		ArrayList<Product> list = ProductController.getInstance().getList(null);
		int number = list.size();
		String[] str = new String[number];
		for(int i=0;i<list.size();i++) {
			str[i] = list.get(i).getName();
		}
		comboBox = new JComboBox(str);
		comboBox.setBounds(117, 105, 196, 23);
		contentPane.add(comboBox);
	}
}
