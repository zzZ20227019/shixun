package com.zhenggangming.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import com.zhenggangming.Dao.ProductDao;
import com.zhenggangming.controller.ProductController;
import com.zhenggangming.controller.ProductKindController;
import com.zhenggangming.model.Product;
import com.zhenggangming.model.ProductKind;
import com.zhenggangming.utils.ProductKindTable;
import com.zhenggangming.utils.ProductTable;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;

public class AddProduct extends JFrame {

	private JPanel contentPane;
	private JTextField serialNumber;
	private JTextField name;
	private JTextField standard;
	private JTextField description;
    private ProductDao productDao = new ProductDao();
    private JButton submit;
    private Product product = new Product();



	/**
	 * Create the frame.
	 * @throws Exception 
	 */
	public AddProduct(JTable table) throws Exception {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 453, 499);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		ArrayList<ProductKind> list = ProductKindController.getInstance().getList(null);
		int number = list.size();
		String[] str = new String[number];
		for(int i=0;i<list.size();i++) {
			str[i] = list.get(i).getName();
		}
		JComboBox comboBox = new JComboBox(str);
		comboBox.setBounds(99, 117, 210, 23);
		contentPane.add(comboBox);
		
		JButton reset = new JButton("返回");
		reset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		reset.setBounds(229, 429, 97, 23);
		contentPane.add(reset);
		JLabel lblNewLabel = new JLabel("产品编号：");
		lblNewLabel.setBounds(29, 37, 60, 15);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("产品类别：");
		lblNewLabel_1.setBounds(29, 121, 70, 15);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("产品名称：");
		lblNewLabel_2.setBounds(29, 76, 68, 15);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("产品规格：");
		lblNewLabel_3.setBounds(31, 167, 68, 15);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("产品描述：");
		lblNewLabel_4.setBounds(29, 217, 60, 15);
		contentPane.add(lblNewLabel_4);
		
		serialNumber = new JTextField();
		serialNumber.setText(productDao.getProductNumber());
		serialNumber.setEditable(false);
		serialNumber.setBounds(99, 34, 210, 21);
		contentPane.add(serialNumber);
		serialNumber.setColumns(10);
		
		name = new JTextField();
		name.setBounds(99, 73, 210, 21);
		contentPane.add(name);
		name.setColumns(10);
		
		standard = new JTextField();
		standard.setBounds(99, 164, 210, 21);
		contentPane.add(standard);
		standard.setColumns(10);
		
		description = new JTextField();
		description.setBounds(99, 214, 210, 171);
		contentPane.add(description);
		description.setColumns(10);
		
		submit = new JButton("提交");
		submit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				product.setSerialNumber(serialNumber.getText());
				product.setName(name.getText());
				product.setKind((String)comboBox.getSelectedItem());
				product.setStandard(standard.getText());
				product.setDescription(description.getText());
				try {
					ProductController.getInstance().register(product);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				JOptionPane.showMessageDialog(contentPane, "添加成功", "标题", JOptionPane.WARNING_MESSAGE);
				ProductTable pkt = null;
				try {
					pkt = new ProductTable(null);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setModel(pkt);
				table.updateUI();
			}
		});
		submit.setBounds(101, 429, 97, 23);
		contentPane.add(submit);
		
		
	}

}
