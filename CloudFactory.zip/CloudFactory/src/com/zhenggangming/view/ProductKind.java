package com.zhenggangming.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.zhenggangming.controller.ProductKindController;
import com.zhenggangming.controller.UserController;
import com.zhenggangming.utils.ProductKindTable;
import com.zhenggangming.utils.UserTable;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class ProductKind extends JFrame {

	private JPanel contentPane;
	private JTextField input;
	private JTable table;

	/**
	 * Create the frame.
	 * @throws Exception 
	 */
	public ProductKind() throws Exception {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 615, 511);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		input = new JTextField();
		input.setBounds(30, 35, 186, 21);
		contentPane.add(input);
		input.setColumns(10);
		
		JButton btnNewButton = new JButton("产品类别查询");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = input.getText();
				ProductKindTable pkt = null;
				try {
					pkt = new ProductKindTable(name);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setModel(pkt);
				table.updateUI();
				
			}
		});
		btnNewButton.setBounds(236, 34, 110, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("重置");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				input.setText("");
				ProductKindTable pkt = null;
				try {
					pkt = new ProductKindTable(null);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setModel(pkt);
				table.updateUI();
			}
		});
		btnNewButton_1.setBounds(393, 34, 97, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("创建");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AddProductKind(table).setVisible(true);
			}
		});
		btnNewButton_2.setBounds(32, 87, 97, 23);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("删除");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ArrayList<String> list = new ArrayList<>();
				int num = table.getRowCount();
				for(int i=0;i<num;i++) {
					if((boolean)table.getValueAt(i, 0)==true) {
						String id = (String) table.getValueAt(i, 1);
						list.add(id);
					}
				}
				try {
					ProductKindController.deleteProductKind(list);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				JOptionPane.showMessageDialog(contentPane, "成功", "标题", JOptionPane.WARNING_MESSAGE);
			    ProductKindTable ut = null;
				try {
					ut = new ProductKindTable(null);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			    table.setModel(ut);
			    table.updateUI();
			}
		});
		btnNewButton_3.setBounds(161, 88, 97, 23);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("修改");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int num = table.getRowCount();
				for(int i=0;i<num;i++) {
					if((boolean)table.getValueAt(i, 0)==true) {
						String id = (String) table.getValueAt(i, 1);
	                    try {
							new ChangeProductKind(id,table).setVisible(true);
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}
			}
		});
		btnNewButton_4.setBounds(394, 93, 97, 23);
		contentPane.add(btnNewButton_4);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(34, 135, 461, 303);
		contentPane.add(scrollPane);
		
		ProductKindTable pkt = new ProductKindTable(null);
		table = new JTable(pkt);
		scrollPane.setViewportView(table);
	}
}
